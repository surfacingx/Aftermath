import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import shutil
import urllib2,urllib
import re
import extract
import time
import downloader
import plugintools
import zipfile
import ntpath

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base           = 'http://cb.kodi-aftermath.net'    #HERE YOU NEED TO INPUT YOUR WEB URL HTTP://MYWEBSPACE.NET
ADDON          = xbmcaddon.Addon(id='plugin.program.apollocosmic')
VERSION        = "1.1"
PATH           = "apollocosmic"
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
AMW            = os.path.join(ADDONS,   'plugin.video.aftermath')
PACKAGES       = os.path.join(ADDONS,   'packages')


def addonInstall():
	url      = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/plugin.video.aftermath/'
	link     = OPEN_URL('%saddon.xml' % url).replace('\n','').replace('\r','').replace('\t','')
	match    = re.compile('<addon.+?id="plugin.video.aftermath".+?ersion="(.+?)".+?>').findall(link)
	addonzip = '%splugin.video.aftermath-%s.zip' % (url, match[0])
	print addonzip
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	lib=os.path.join(PACKAGES, addonzip)
	try: os.remove(lib)
	except: pass
	downloader.download(url+addonzip,lib)
	extract.all(lib, ADDONS)
	xbmc.sleep(1000)
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.sleep(1000)
	
if not os.path.exists(AMW): addonInstall()