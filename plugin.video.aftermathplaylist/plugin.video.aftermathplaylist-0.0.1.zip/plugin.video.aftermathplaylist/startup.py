import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathplaylist'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Playlist[/COLOR][/B]'
VERSION        = '0.0.1'
PLAYLIST       = ADDON.getSetting('playlist')
ADULT          = ADDON.getSetting('showadult')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
ADDONS         = xbmc.translatePath('special://home/addons')
LISTDIR        = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/',ADDON_ID))
PACKAGES       = xbmc.translatePath('special://home/addons/packages')
FANART         = os.path.join(ADDONS, ADDON_ID , 'fanart.jpg')
ICON           = os.path.join(ADDONS, ADDON_ID, 'icon.png')
ART            = os.path.join(ADDONS, ADDON_ID + '/resources/art/')
LIST           = os.path.join(LISTDIR,'favourites.xml')
MODURL         = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
BASEURL        = 'http://r.srfx.in/playlist/'
AFTERMATH      = 'http://r.srfx.in/playlist/aftermath.txt'

def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def LogNotify(title,message,times,icon):
	xbmc.executebuiltin("XBMC.Notification("+title+","+message+","+times+","+ICON+")")

def checkUpdate():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<aftermath><name>Aftermath Playlist</name><version>(.+?)</version></aftermath>').findall(link)
	if match[0] > PLAYLIST or not os.path.exists(LISTDIR):
		redoList()
		
def redoList():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<aftermath><name>Aftermath Playlist</name><version>(.+?)</version></aftermath>').findall(link)
	if os.path.exists(LISTDIR): 
		shutil.rmtree(LISTDIR,ignore_errors=True, onerror=None)
		os.makedirs(LISTDIR)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	ADDON.setSetting('showadult', ADULT)
	ADDON.setSetting('playlist', match[0])
	url = BASEURL+'playlist.zip'
	DP.create(ADDONTITLE,"Downloading updated list!","", "Please Wait")
	lib=os.path.join(PACKAGES, 'playlist.zip')
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	xbmc.sleep(200)
	DP.update(0,"Updating Aftermath Playlist","", "Please Wait")
	ext=extract.all(lib,LISTDIR, DP)
	if not ext == True:
		print "ERROR UPDATING LIST"
		LogNotify(ADDONTITLE,'Playlist: [COLOR green]Failed[/COLOR]', '1000', ICON)
	DP.close()
	LogNotify(ADDONTITLE,'Playlist: [COLOR green]Updated[/COLOR]', '1000', ICON)
	xbmc.executebuiltin('Container.Refresh()')
	
checkUpdate()