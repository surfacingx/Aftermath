import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathplaylist'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Playlist[/COLOR][/B]'
VERSION        = '0.0.1'
PLAYLIST       = ADDON.getSetting('playlist')
ADULT          = ADDON.getSetting('showadult')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
ADDONS         = xbmc.translatePath('special://home/addons')
LISTDIR        = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/',ADDON_ID))
PACKAGES       = xbmc.translatePath('special://home/addons/packages')
FANART         = os.path.join(ADDONS, ADDON_ID , 'fanart.jpg')
ICON           = os.path.join(ADDONS, ADDON_ID, 'icon.png')
ART            = os.path.join(ADDONS, ADDON_ID + '/resources/art/')
LIST           = os.path.join(LISTDIR,'favourites.xml')
MODURL         = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
BASEURL        = 'http://r.srfx.in/playlist/'
AFTERMATH      = 'http://r.srfx.in/playlist/aftermath.txt'

#################################
####### MENUS ###################
#################################

def index():
	checkUpdate()
	addFile('Aftermath [COLOR white][B]Playlists[/B][/COLOR]','','','',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	list = open(LIST,mode='r'); g = list.read().replace('\n','').replace('\r',''); list.close()
	match = re.compile('<name>(.+?)</name>').findall(g)
	for name in match:
		if name == 'Adult': 
			show = ADDON.getSetting('showadult')
			if show == 'true': addDir('Aftermath [COLOR white][B]'+str(name)+'[/B][/COLOR]','playlist',str(name),'',FANART)
		else: addDir('Aftermath [COLOR white][B]'+str(name)+'[/B][/COLOR]','playlist',str(name),'',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addFile('Aftermath [COLOR white][B]Force Update List[/B][/COLOR]','updatelist','','',FANART)
	addFile('Aftermath [COLOR white][B]Settings[/B][/COLOR]','settings','','',FANART)
	setView('movies', 'MAIN')

def viewList(list):
	loc = getData('main', list, 'list')
	loc = os.path.join(LISTDIR,loc)
	des = getData('main', list, 'description')
	dl  = getData('main', list, 'download')
	addFile('Aftermath [COLOR white][B]Playlists[/B][/COLOR]: [COLOR dodgerblue][B]'+list+'[/B][/COLOR]','','','',FANART)
	addFile('[COLOR white][B][I]'+des+'[/I][/B][/COLOR]','','','',FANART)
	addFile('[COLOR dodgerblue]=================================================+[/COLOR]','','','',FANART)
	if os.path.exists(loc):
		xml = open(loc,mode='r'); g = xml.read().replace('\n','').replace('\r',''); xml.close()
		match = re.compile('<name>(.+?)</name>.+?<addon>(.+?)</addon>').findall(g)
		if len(match) > 0:
			for name, addon in match:
				a=os.path.join(ADDONS, addon)
				if os.path.exists(a): addFile('[COLOR green][B]'+str(name)+'[/B][/COLOR]','launchaddon',str(name),list,FANART)
				else: addFile('[COLOR red][B]'+str(name)+'[/B][/COLOR]','install',str(name),list,FANART)
		else:
			if list == 'Fight Night':
				addFile('[COLOR white][B]Currently no PPV scheduled.[/B][/COLOR]','','','',FANART)
			else:
				addFile('[COLOR white][B]Currently no '+list+'.[/B][/COLOR]','','','',FANART)
	else:
		if list == 'Fight Night':
			addFile('[COLOR white][B]Currently no PPV scheduled.[/B][/COLOR]','','','',FANART)
		else:
			addFile('[COLOR white][B]Currently no '+list+'.[/B][/COLOR]','','','',FANART)
	addFile('[COLOR dodgerblue]=================================================+[/COLOR]','','','',FANART)
	addFile('Aftermath [COLOR white][B]Download '+list+' Pack[/B][/COLOR]','installall','',list,FANART)
	setView('movies', 'MAIN')

def workingURL(url):
    try: 
	    req = urllib2.Request(url)
	    response = urllib2.urlopen(req)
	    response.close()
    except Exception, e:
	    return e
    return True
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def getData(type ,lname, ret, parent=None):
	if type == 'main':
		list = open(LIST,mode='r'); g = list.read().replace('\n','').replace('\r','').replace('\t',''); list.close()
		match = re.compile('<shortcut><name>(.+?)</name><description>(.+?)</description><list>(.+?)</list><download>(.+?)</download></shortcut>').findall(g)
		for name, description, list, download in match:
			if name == lname:
				if ret == 'description':
					return description
				elif ret == 'list':
					return list
				elif ret == 'download':
					return download
					
	elif type == 'sub':
		url = os.path.join(LISTDIR,parent,'favourites.xml')
		list = open(url,mode='r'); g = list.read().replace('\n','').replace('\r','').replace('\t',''); list.close()
		match = re.compile('<shortcut><name>'+lname+'</name><addon>(.+?)</addon><thumb>(.+?)</thumb><url>(.+?)</url><repo>(.+?)</repo><repozip>(.+?)</repozip><addonzip>(.+?)</addonzip><alt>(.+?)</alt></shortcut>').findall(g)
		for addon, thumb, url, repo, repozip, addonzip, alt in match:
			if ret == 'addon':
				return addon
			elif ret == 'thumb':
					return thumb
			elif ret == 'url':
				return url
			elif ret == 'repo':
				return repo
			elif ret == 'repozip':
				return repozip
			elif ret == 'addonzip':
				return addonzip
			elif ret == 'alt':
				return alt


def launchAddon(name,list):
	url = getData('sub',name,'url',list)
	if list == "Maintenance": action = "PlayMedia("+url+", return)"
	else: action = "ActivateWindow(video, "+url+", return)"
	print action
	xbmc.executebuiltin(action)
	
def LogNotify(title,message,times,icon):
	xbmc.executebuiltin("XBMC.Notification("+title+","+message+","+times+","+ICON+")")

def checkUpdate():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<aftermath><name>Aftermath Playlist</name><version>(.+?)</version></aftermath>').findall(link)
	if match[0] > PLAYLIST or not os.path.exists(LISTDIR):
		redoList()
	
def redoList():
	link = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<aftermath><name>Aftermath Playlist</name><version>(.+?)</version></aftermath>').findall(link)
	if os.path.exists(LISTDIR): 
		shutil.rmtree(LISTDIR,ignore_errors=True, onerror=None)
		os.makedirs(LISTDIR)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	ADDON.setSetting('showadult', ADULT)
	ADDON.setSetting('playlist', match[0])
	url = BASEURL+'playlist.zip'
	DP.create(ADDONTITLE,"Downloading updated list!","", "Please Wait")
	lib=os.path.join(PACKAGES, 'playlist.zip')
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	xbmc.sleep(200)
	DP.update(0,"Updating Aftermath Playlist","", "Please Wait")
	ext=extract.all(lib,LISTDIR, DP)
	if not ext == True:
		print "ERROR UPDATING LIST"
	DP.close()
	DIALOG.ok(ADDONTITLE, 'Playlists have been updated.')
	xbmc.executebuiltin('Container.Refresh()')
	
if not os.path.exists(LISTDIR): redoList()
	
def installPack(name):
	addonzip = BASEURL+getData('main',name,'download')
	valid    = workingURL(addonzip)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	if valid == True: 
		DP.create(ADDONTITLE,"Downloading: [COLOR yellow]"+name+" Addon Pack[/COLOR]","", "Please Wait")
		lib=os.path.join(PACKAGES, name+'.zip')
		try: os.remove(lib)
		except: pass
		downloader.download(addonzip, lib, DP)
		xbmc.sleep(200)
		DP.update(0,"Installing: [COLOR yellow]"+name+" Addon Pack[/COLOR]","", "Please Wait")
		ext=extract.all(lib,ADDONS, DP)
		if ext == True:
			DP.close()
			xbmc.sleep(300)
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.sleep(300)
			LogNotify(ADDONTITLE,list+' Pack: [COLOR green]Installed[/COLOR]', '1000', ICON)
		else:
			DP.close()
			DIALOG.ok(ADDONTITLE, "ERROR INSTALLING: [COLOR yellow]"+name+" Addon Pack[/COLOR]", str(ext))
			LogNotify(ADDONTITLE,list+' Pack: [COLOR red]ERROR![/COLOR]', '1000', ICON)
	else: 
		DIALOG.ok(ADDONTITLE, "ERROR DOWNLOADING: [COLOR yellow]"+name+" Addon Pack[/COLOR]", str(valid))
		LogNotify(ADDONTITLE,list+' Pack: [COLOR red]ERROR![/COLOR]', '1000', ICON)
	xbmc.executebuiltin('Container.Refresh()')
	
def installAddon(name, list):
	repozip   = getData('sub',name,'repozip',list)
	addonzip  = getData('sub',name,'addonzip',list)
	alt       = BASEURL+getData('sub',name,'alt',list)
	plugin    = getData('sub',name,'addon',list)
	reponame  = getData('sub',name,'repo',list)
	repo      = os.path.join(ADDONS, reponame)
	#Install repo
	if not os.path.exists(repo) and not reponame == 'none':
		repovalid = workingURL(repozip)
		if repovalid == True:
			if DIALOG.yesno(ADDONTITLE, "Would you like to install the repo for [COLOR yellow]"+name+"[/COLOR]?","[COLOR yellow]"+reponame+"[/COLOR]", nolabel='Don\'t Install',yeslabel='Install'): 
				DP.create(ADDONTITLE,"Downloading [COLOR yellow]"+name+"[/COLOR]'s Repository","", "Please Wait")
				lib=os.path.join(PACKAGES, reponame+'.zip')
				try: os.remove(lib)
				except: pass
				downloader.download(repozip, lib, DP)
				xbmc.sleep(200)
				DP.update(0,"Installing [COLOR yellow]"+name+"[/COLOR]'s Repository","", "Please Wait")
				x=extract.all(lib,ADDONS, DP)
				if not str(x) == 'True':
					DP.update(0, "Error Installing Repo for [COLOR yellow]"+name+"[/COLOR]")
				DP.close()
		else: print "Error Repo URL:"+str(repovalid)
	#Install Addon
	addonvalid = workingURL(addonzip)
	altvalid = workingURL(alt)
	if not addonzip == 'none':
		if addonvalid == True:
			DP.create(ADDONTITLE,"Downloading Primary Source for [COLOR yellow]"+name+"[/COLOR]",'', 'Please Wait')
			lib=os.path.join(PACKAGES, plugin+'.zip')
			try: os.remove(lib)
			except: pass
			downloader.download(addonzip, lib, DP)
			xbmc.sleep(200)
			DP.update(0,"Installing "+ name,'', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				if DIALOG.yesno(ADDONTITLE, "ERROR DOWNLOADING PRIMARY METHOD FOR: [COLOR yellow]"+name+"[/COLOR]", "Would you like to try to alternate method?", str(x), nolabel="No, Cancel", yeslabel="Yes, Option 2"):
					lib=os.path.join(PACKAGES, plugin+'.zip')
					downloader.download(alt, lib, DP)
					xbmc.sleep(200)
					DP.update(0,"Installing Alternate Method for: [COLOR yellow]"+name+"[/COLOR]",'', 'Please Wait')
					ext=extract.all(lib,ADDONS, DP)
					if not ext == True:
						DIALOG.ok(ADDONTITLE, "ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]"+name+"[/COLOR]", "Both Primary and Alternate Failed!", "You can still install the Addon with the "+list+" Pack Below!")
					DP.close()
				else: 
					DIALOG.ok(ADDONTITLE, "Alternate Source was not installed!")
					LogNotify(ADDONTITLE,name+': [COLOR red]Install Failed![/COLOR]', '1000', ICON)
					return
			DP.close()
		else: 
			lib=os.path.join(PACKAGES, plugin+'.zip')
			downloader.download(alt, lib, DP)
			xbmc.sleep(200)
			DP.update(0,"Installing Alternate Method for: [COLOR yellow]"+name+"[/COLOR]",'', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				DIALOG.ok(ADDONTITLE, "ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]"+name+"[/COLOR]", "Both Primary and Alternate Failed!", "You can still install the Addon with the "+list+" Pack Below!")
				LogNotify(ADDONTITLE,name+': [COLOR red]Install Failed![/COLOR]', '1000', ICON)
			DP.close()
	else: 
		if altvalid == True:
			DP.create(ADDONTITLE,"Downloading Alternate Source for: [COLOR yellow]"+name+"[/COLOR]",'', 'Please Wait')
			lib=os.path.join(PACKAGES, plugin+'.zip')
			try: os.remove(lib)
			except: pass
			downloader.download(alt, lib, DP)
			xbmc.sleep(200)
			DP.update(0,"Installing "+ name,'', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				DIALOG.ok(ADDONTITLE, "ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]"+name+"[/COLOR]", "Both Primary and Alternate Failed!", "You can still install the Addon with the "+list+" Pack Below!")
				LogNotify(ADDONTITLE,name+': [COLOR red]Install Failed![/COLOR]', '1000', ICON)
				DP.close()
				return
		else: 
			DIALOG.ok(ADDONTITLE, "Primary and Alternate links are broken for: [COLOR yellow]"+name+"[/COLOR]", "You can still install the Addon with the "+list+" Pack Below!")
			LogNotify(ADDONTITLE,name+': [COLOR red]Install Failed![/COLOR]', '1000', ICON)
			return
	#Install dependency	
	dep=os.path.join(ADDONS,getData('sub',name,'addon',list),'addon.xml')
	if os.path.exists(dep):
		source=open(dep,mode='r'); link=source.read(); source.close(); 
		match=re.compile('import addon="(.+?)"').findall(link)
		for depends in match:
			if not 'xbmc.python' in depends:
				dependspath=os.path.join(ADDONS,depends)
				if not os.path.exists(dependspath): 
					depzip = MODURL+depends+'.zip'
					lib=os.path.join(PACKAGES, depends+'.zip')
					try: os.remove(lib)
					except: pass
					DP.update(0,"Downloading dependency: [COLOR yellow]"+depends+"[/COLOR]","", "Please Wait")
					downloader.download(depzip, lib, DP)
					xbmc.sleep(100)
					DP.update(0,"Installing dependency: [COLOR yellow]"+depends+"[/COLOR]","", "Please Wait")
					ext=extract.all(lib,ADDONS, DP)
					if not ext == True: print "DEPENDENCY INSTALL FAIL:"+depends
					xbmc.sleep(100)
		DP.close()
	xbmc.sleep(300)
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.sleep(300)
	LogNotify(ADDONTITLE,name+': [COLOR green]Installed[/COLOR]', '1000', ICON)
	xbmc.executebuiltin('Container.Refresh()')
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleaneDParams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleaneDParams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(display,view,name,list,fanart):
        u=sys.argv[0]+"?view="+urllib.quote_plus(view)
        if len(name) > 0: u += "&name="+urllib.quote_plus(name)
        if len(list) > 0: u += "&list="+urllib.quote_plus(list)
        ok=True
        display = display.replace('Aftermath', '[COLOR dodgerblue][B]Aftermath[/B][/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=ICON)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
        liz.setProperty( "Fanart_Image", fanart )
     	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addFile(display,view,name,list,fanart):
        u=sys.argv[0]+"?view="+urllib.quote_plus(view)
        if len(name) > 0: u += "&name="+urllib.quote_plus(name)
        if len(list) > 0: u += "&list="+urllib.quote_plus(list)
        ok=True
        display = display.replace('Aftermath', '[COLOR dodgerblue][B]Aftermath[/B][/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=ICON)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Playlist" } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

		
params=get_params()
view=None
name=None
list=None


try:
        view=urllib.unquote_plus(params["view"])
except:
        pass
try:        
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:        
        list=urllib.unquote_plus(params["list"])
except:
        pass

        
print str(ADDONTITLE)+': '+str(VERSION)
print "View: "+str(view)
print "Name: "+str(name)
print "List: "+str(list)

def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

if view==None: index()
elif view=='playlist': viewList(name)
elif view=='launchaddon': launchAddon(name,list)
elif view=='install': installAddon(name,list)
elif view=='installall': installPack(list)
elif view=='updatelist': redoList()
elif view=='settings': ADDON.openSettings()

xbmcplugin.endOfDirectory(int(sys.argv[1]))