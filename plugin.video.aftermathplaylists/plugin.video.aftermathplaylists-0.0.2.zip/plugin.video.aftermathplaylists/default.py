import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathplaylists'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Playlists[/COLOR][/B]'
VERSION        = '0.0.1'
PLAYLIST       = ADDON.getSetting('playlist')
UPDATED        = ADDON.getSetting('updated')
ADULT          = ADDON.getSetting('showadult')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
REPO           = os.path.join(ADDONS,   'repository.aftermath')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
LISTDIR        = os.path.join(USERDATA, 'addon_data', ADDON_ID)
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   'resources', 'art')
LIST           = os.path.join(LISTDIR,  'favourites.xml')
MODURL         = 'http://tribeca.tvaddons.ag/tools/maintenance/modules/'
BASEURL        = 'http://cb.srfx.in/playlist/'
AFTERMATH      = 'http://cb.srfx.in/aftermath.xml'
TODAY          = datetime.date.today()

#################################
####### MENUS ###################
#################################

def index():
	checkUpdate()
	addFile('Aftermath Playlists', icon=os.path.join(ART,'icon.png'))
	addFile('[COLOR dodgerblue]Version:[/COLOR] v%s / [COLOR dodgerblue]Updated:[/COLOR] %s' % (PLAYLIST, UPDATED), icon=os.path.join(ART,'icon.png'))
	addFile('[COLOR dodgerblue]==================================================[/COLOR]', icon=os.path.join(ART,'icon.png'))
	list = open(LIST,mode='r'); g = list.read().replace('\n','').replace('\r',''); list.close()
	match = re.compile('<name>(.+?)</name>').findall(g)
	for name in match:
		if name == 'Adult': 
			show = ADDON.getSetting('showadult')
			if show == 'true': addDir('Aftermath %s' % name,'playlist',name, icon=os.path.join(ART,'%s.png' % name.replace(' ', '').replace('/', '').lower()))
		else: addDir('Aftermath %s' % name,'playlist',name, icon=os.path.join(ART,'%s.png' % name.replace(' ', '').replace('/', '').lower()))
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addFile('Aftermath Force Update List', 'updatelist', icon=os.path.join(ART,'forcerefresh.png'))
	addFile('Aftermath Settings', 'settings', icon=os.path.join(ART,'settings.png'))
	setView('movies', 'MAIN')

def viewList(list):
	loc  = getData('main', list, 'list')
	loc  = os.path.join(LISTDIR,loc)
	des  = getData('main', list, 'description')
	dl   = getData('main', list, 'download')
	iconz=os.path.join(ART,'%s.png' % list.replace(' ', '').replace('/', '').lower())
	addFile('Aftermath Playlists: [COLOR dodgerblue]%s[/COLOR]' % list, icon=iconz)
	addFile('[I]%s[/I]' % des, icon=iconz)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]', icon=iconz)
	if os.path.exists(loc):
		xml = open(loc,mode='r'); g = xml.read().replace('\n','').replace('\r',''); xml.close()
		match = re.compile('<name>(.+?)</name>.+?<addon>(.+?)</addon>').findall(g)
		if len(match) > 0:
			count    = 0
			for name, addon in match:
				count += 1 
				lead = str(count).zfill(2)
				art = getArt(name, list,'fanart.jpg'); icon = getArt(name, list,'icon.png'); a = os.path.join(ADDONS, addon);
				if os.path.exists(a): addFile('[%s][COLOR green] %s[/COLOR]' % (lead, name), 'launchaddon', name, list, art, icon)
				else: addFile('[%s][COLOR red] %s[/COLOR]' % (lead, name), 'install', name, list, art, icon)
		else:
			if list == 'Fight Night': addFile('Currently no PPV scheduled.', icon=iconz)
			else: addFile('Currently no %s.' % list, icon=iconz)
	else:
		if list == 'Fight Night': addFile('Currently no PPV scheduled.', icon=iconz)
		else: addFile('Currently no %s.' % list, icon=iconz)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]', icon=iconz)
	#addFile('Aftermath Install %s Pack' % list,'installall', None,list)
	setView('movies', 'MAIN')

def workingURL(url):
    try: 
	    req = urllib2.Request(url)
	    response = urllib2.urlopen(req)
	    response.close()
    except Exception, e:
	    return e
    return True
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def getArt(name, parent, file):
	plugin = getData('sub',name,'addon', parent)
	art = getData('sub',name,'artwork', parent)
	addon = os.path.join(ADDONS, plugin)
	if os.path.exists(addon): 
		return os.path.join(addon,file)
	else:
		return art+file
	
def getData(type ,lname, ret, parent=None):
	if type == 'main':
		list = open(LIST, mode='r'); g = list.read().replace('\n','').replace('\r','').replace('\t',''); list.close()
		match = re.compile('<shortcut><name>%s</name><description>(.+?)</description><list>(.+?)</list><download>(.+?)</download></shortcut>' % lname).findall(g)
		if len(match) > 0:
			for description, list, download in match:
				if ret   == 'description': return description
				elif ret == 'list':        return list
				elif ret == 'download':    return download
		else: return False
	elif type == 'sub':
		fold = getData('main', parent, 'list')
		url = os.path.join(LISTDIR, fold)
		if not os.path.exists(url): return False
		list = open(url, mode='r'); g = list.read().replace('\n','').replace('\r','').replace('\t',''); list.close()
		match = re.compile('<shortcut><name>%s</name><addon>(.+?)</addon><artwork>(.+?)</artwork><url>(.+?)</url><repo>(.+?)</repo><repoxml>(.+?)</repoxml><repozip>(.+?)</repozip><addonxml>(.+?)</addonxml><addonzip>(.+?)</addonzip><alt>(.+?)</alt></shortcut>' % lname).findall(g)
		for addon, artwork, url, repo, repoxml, repozip, addonxml, addonzip, alt in match:
			if ret == 'addon':      return addon
			elif ret == 'artwork':  return artwork
			elif ret == 'url':      return url
			elif ret == 'repo':     return repo
			elif ret == 'repozip':  return repozip
			elif ret == 'repoxml':  return repoxml
			elif ret == 'addonxml': return addonxml
			elif ret == 'addonzip': return addonzip
			elif ret == 'alt':      return alt

def launchAddon(name,list):
	url = getData('sub',name,'url',list)
	if list == "Maintenance": action = "PlayMedia(%s, return)" % url
	else: action = "ActivateWindow(video, %s, return)" % url
	xbmc.executebuiltin(action)
	
def LogNotify(title,message,times=2000,icon=ICON):
	xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s, False)' % (title , message , times, icon))

def checkUpdate():
	link  = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<addon><name>Aftermath Playlist</name><version>(.+?)</version></addon>').findall(link)
	if match[0] > PLAYLIST or not os.path.exists(LIST):
		redoList()
	
def redoList():
	link  = OPEN_URL(AFTERMATH).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<addon><name>Aftermath Playlist</name><version>(.+?)</version></addon>').findall(link)
	if os.path.exists(LISTDIR): 
		shutil.rmtree(LISTDIR,ignore_errors=True, onerror=None)
		os.makedirs(LISTDIR)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	ADDON.setSetting('showadult', ADULT)
	ADDON.setSetting('playlist', match[0])
	ADDON.setSetting('updated', str(TODAY))
	url = '%splaylist.zip' % BASEURL
	DP.create(ADDONTITLE, 'Downloading updated list!', '', 'Please Wait')
	lib=os.path.join(PACKAGES, 'playlist.zip')
	try: os.remove(lib)
	except: pass
	downloader.download(url, lib, DP)
	xbmc.sleep(200)
	DP.update(0, 'Updating Aftermath Playlist"', '', 'Please Wait')
	ext = extract.all(lib, LISTDIR, DP)
	if not ext == True: print "ERROR UPDATING LIST"
	DP.close()
	DIALOG.ok(ADDONTITLE, 'Playlists have been updated.')
	xbmc.executebuiltin('Container.Refresh()')
	
if not os.path.exists(LISTDIR): redoList()

def installed(addon):
	icon = os.path.join(ADDONS,addon,'icon.png')
	url = os.path.join(ADDONS,addon,'addon.xml')
	if os.path.exists(url):
		list = open(url,mode='r'); g = list.read().replace('\n','').replace('\r',''); list.close()
		match = re.compile('<addon.+?name="(.+?)".+?>').findall(g)
		LogNotify(match[0],'Addon Enabled', '2000', icon)
		
def installDep(name):
	print 'dep install: %s' % name
	dep=os.path.join(ADDONS,name,'addon.xml')
	if os.path.exists(dep):
		source=open(dep,mode='r'); link=source.read(); source.close(); 
		match=re.compile('import addon="(.+?)"').findall(link)
		for depends in match:
			if not 'xbmc.python' in depends:
				dependspath=os.path.join(ADDONS, depends)
				if not os.path.exists(dependspath):
					if depends == 'script.exodus.artwork': depzip = 'http://offshoregit.com/exodus/script.exodus.artwork/script.exodus.artwork-1.0.0.zip'
					else: depzip = '%s%s.zip' % (MODURL, depends)
					lib=os.path.join(PACKAGES, '%s.zip' % depends)
					try: os.remove(lib)
					except: pass
					DP.update(0, 'Downloading dependency: [COLOR yellow]%s[/COLOR]' % depends, '', 'Please Wait')
					downloader.download(depzip, lib, DP)
					xbmc.sleep(100)
					DP.update(0, 'Installing dependency: [COLOR yellow]%s[/COLOR]' % depends, '', 'Please Wait')
					ext=extract.all(lib,ADDONS, DP)
					if not ext == True: 
						print '========================================='; print '|Aftermath Playlist                     |'; print '========================================='
						print 'DEPENDENCY INSTALL FAIL: %s' % depends
					else: 
						installDep(depends)
						installed(depends)
					xbmc.sleep(100)
					DP.close()
		
def installPack(name):
	addonzip = BASEURL+getData('main', name, 'download')
	valid    = workingURL(addonzip)
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	if valid == True: 
		DP.create(ADDONTITLE,'Downloading: [COLOR yellow]%s Addon Pack[/COLOR]' % name, '', 'Please Wait')
		lib=os.path.join(PACKAGES, '%s.zip' % name)
		try: os.remove(lib)
		except: pass
		downloader.download(addonzip, lib, DP)
		xbmc.sleep(200)
		DP.update(0,'Installing: [COLOR yellow]%s Addon Pack[/COLOR]' % name, '', 'Please Wait')
		ext=extract.all(lib,ADDONS, DP)
		if ext == True:
			DP.close()
			xbmc.sleep(300)
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.sleep(300)
			LogNotify(ADDONTITLE, '%s Pack: [COLOR green]Installed[/COLOR]' % list)
		else:
			DP.close()
			DIALOG.ok(ADDONTITLE, 'ERROR INSTALLING: [COLOR yellow]%s Addon Pack[/COLOR]' % name, str(ext))
			LogNotify(ADDONTITLE, '%s Pack: [COLOR red]ERROR![/COLOR]' % list)
	else: 
		DIALOG.ok(ADDONTITLE, 'ERROR DOWNLOADING: [COLOR yellow]%s Addon Pack[/COLOR]' % name, str(valid))
		LogNotify(ADDONTITLE, '%s Pack: [COLOR red]ERROR![/COLOR]' % list)
	xbmc.executebuiltin('Container.Refresh()')
	
def installAddon(name, list):
	repozip   = getData('sub',name,'repozip',list)
	addonzip  = getData('sub',name,'addonzip',list)
	alt       = BASEURL+getData('sub',name,'alt',list)
	plugin    = getData('sub',name,'addon',list)
	repoxml   = getData('sub',name,'repoxml',list)
	reponame  = getData('sub',name,'repo',list)
	xml       = getData('sub',name,'addonxml',list)
	repo      = os.path.join(ADDONS, reponame)
	link      = OPEN_URL(xml).replace('\n','').replace('\r','').replace('\t','')
	match     = re.compile('<addon.+?id="%s".+?ersion="(.+?)".+?>' % plugin).findall(link)
	addonzip  = '%s%s-%s.zip' % (addonzip, plugin, match[0])
	#Install repo
	if not os.path.exists(repo) and not reponame == 'none':
		if not repoxml == 'none':
			link    = OPEN_URL(repoxml).replace('\n','').replace('\r','').replace('\t','')
			match   = re.compile('<addon.+?id="%s".+?ersion="(.+?)".+?>' % reponame).findall(link)
			repozip = '%s%s-%s.zip' % (repozip, reponame, match[0])
		repovalid = workingURL(repozip)
		if repovalid == True:
			if DIALOG.yesno(ADDONTITLE, "Would you like to install the repo for [COLOR yellow]"+name+"[/COLOR]?","[COLOR yellow]"+reponame+"[/COLOR]", nolabel='Don\'t Install',yeslabel='Install'): 
				DP.create(ADDONTITLE, 'Downloading [COLOR yellow]%s[/COLOR]\'s Repository' %reponame, '', 'Please Wait')
				lib=os.path.join(PACKAGES, '%s.zip' % reponame)
				try: os.remove(lib)
				except: pass
				downloader.download(repozip, lib, DP)
				xbmc.sleep(200)
				DP.update(0,'Installing [COLOR yellow]%s[/COLOR]\'s Repository' % name, '', 'Please Wait')
				ext=extract.all(lib,ADDONS, DP)
				if not ext == True:
					DP.update(0, "Error Installing Repo for [COLOR yellow]%s[/COLOR]" % name)
				DP.close()
				installed(reponame)
		else: print "Error Repo URL: %s" % str(repovalid)
	#Install Addon
	addonvalid = workingURL(addonzip)
	altvalid = workingURL(alt)
	if not addonzip == 'none':
		if addonvalid == True:
			DP.create(ADDONTITLE, 'Downloading Primary Source for [COLOR yellow]%s[/COLOR]' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % plugin)
			try: os.remove(lib)
			except: pass
			downloader.download(addonzip, lib, DP)
			xbmc.sleep(200)
			DP.update(0,'Installing %s' % name,'', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				if DIALOG.yesno(ADDONTITLE, 'ERROR DOWNLOADING PRIMARY METHOD FOR: [COLOR yellow]%s[/COLOR]' % name, 'Would you like to try to alternate method?', str(x), nolabel='No, Cancel', yeslabel='Yes, Option 2'):
					lib=os.path.join(PACKAGES, '%s.zip' % plugin)
					downloader.download(alt, lib, DP)
					xbmc.sleep(200)
					DP.update(0, 'Installing Alternate Method for: [COLOR yellow]%s[/COLOR]' % name, '', 'Please Wait')
					ext=extract.all(lib,ADDONS, DP)
					if not ext == True:
						DIALOG.ok(ADDONTITLE, 'ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]%s[/COLOR]' % name, 'Both Primary and Alternate Failed!', 'You can still install the Addon with the %s Pack Below!' % list)
					else: installed(plugin)
					DP.close()
				else: 
					DIALOG.ok(ADDONTITLE, 'Alternate Source was not installed!')
					LogNotify(ADDONTITLE, '%s: [COLOR red]Install Failed![/COLOR]' % name)
					return
			DP.close()
			installed(plugin)
		else: 
			DP.create(ADDONTITLE, 'Downloading Alternate Source for [COLOR yellow]%s[/COLOR]' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % plugin)
			downloader.download(alt, lib, DP)
			xbmc.sleep(200)
			DP.update(0, 'Installing Alternate Method for: [COLOR yellow]%s[/COLOR]' % name,'', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				DIALOG.ok(ADDONTITLE, 'ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]%s[/COLOR]' % name, 'Both Primary and Alternate Failed!', 'You can still install the Addon with the %s Pack Below!' % list)
				LogNotify(ADDONTITLE, '%s: [COLOR red]Install Failed![/COLOR]' % name)
			DP.close()
			installed(plugin)
	else: 
		if altvalid == True:
			DP.create(ADDONTITLE, 'Downloading Alternate Source for: [COLOR yellow]%s[/COLOR]' % name, '', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % plugin)
			try: os.remove(lib)
			except: pass
			downloader.download(alt, lib, DP)
			xbmc.sleep(200)
			DP.update(0,'Installing %s' % name, '', 'Please Wait')
			ext=extract.all(lib,ADDONS, DP)
			if not ext == True:
				DIALOG.ok(ADDONTITLE, 'ERROR DOWNLOADING ALTERNATE METHOD FOR: [COLOR yellow]%s[/COLOR]' % name, 'Both Primary and Alternate Failed!', 'You can still install the Addon with the %s Pack Below!' % list)
				LogNotify(ADDONTITLE, '%s: [COLOR red]Install Failed![/COLOR]' % name)
				DP.close()
				return
			installed(plugin)
		else: 
			DIALOG.ok(ADDONTITLE, 'Primary and Alternate links are broken for: [COLOR yellow]%s[/COLOR]' % name, 'You can still install the Addon with the %s Pack Below!' % list)
			LogNotify(ADDONTITLE, '%s: [COLOR red]Install Failed![/COLOR]' % name)
			return
	#Install dependency
	installDep(plugin)
	xbmc.sleep(300)
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh()')
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleaneDParams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleaneDParams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(display,view=None,name=None,list=None,fanart=FANART,icon=ICON):
        u=sys.argv[0]
        if not view == None: u += "?view="+urllib.quote_plus(view)
        if not name == None: u += "&name="+urllib.quote_plus(name)
        if not list == None: u += "&list="+urllib.quote_plus(list)
        ok=True
        display = '[B][COLOR white]%s[/COLOR][/B]' % display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Playlist" } )
        liz.setProperty( "Fanart_Image", fanart )
     	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addFile(display,view=None,name=None,list=None,fanart=FANART,icon=ICON):
        u=sys.argv[0]
        if not view == None: u += "?view="+urllib.quote_plus(view)
        if not name == None: u += "&name="+urllib.quote_plus(name)
        if not list == None: u += "&list="+urllib.quote_plus(list)
        ok=True
        display = '[B][COLOR white]%s[/COLOR][/B]' % display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

		
params=get_params()
view=None
name=None
list=None

try:     view=urllib.unquote_plus(params["view"])
except:  pass
try:     name=urllib.unquote_plus(params["name"])
except:  pass
try:     list=urllib.unquote_plus(params["list"])
except:  pass
        
print '%s: %s' % (ADDONTITLE, VERSION)
print "View: %s" % view
print "Name: %s" % name
print "List: %s" % list

def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )

if view==None: index()
elif view=='playlist': viewList(name)
elif view=='launchaddon': launchAddon(name,list)
elif view=='install': installAddon(name,list)
elif view=='installall': installPack(list)
elif view=='updatelist': redoList()
elif view=='settings': ADDON.openSettings(); xbmc.executebuiltin('Container.Refresh')

xbmcplugin.endOfDirectory(int(sys.argv[1]))