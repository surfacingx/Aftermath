import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import urllib2,urllib
import re
import time
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net

ADDON_ID       = 'plugin.video.aftermath'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
VERSION        = '0.1.0'
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,	 'addons')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
CHANHELOG      = os.path.join(PLUGIN,   'changelog.txt')
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   'resources', 'art')
BASEURL        = "http://cb.srfx.in/"
BUILDSURL      = "http://cb.srfx.in/builds/"
INFOURL        = "http://cb.srfx.in/info/"
AFTERMATHXML   = "http://cb.srfx.in/aftermath.xml"

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
	WINDOW=10147
	CONTROL_LABEL=1
	CONTROL_TEXTBOX=5
	def __init__(self,*args,**kwargs):
	  xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
	  self.win=xbmcgui.Window(self.WINDOW) # get window
	  xbmc.sleep(500) # give window time to initialize
	  self.setControls()
	def setControls(self):
	  self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
	  try: f=open(announce); text=f.read()
	  except: text=announce
	  self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
	  return
  TextBox()
  
#################################
####### Welcome Screen   ########
#################################
# based on H99's & tknorris splash code
def WelcomeScreen(msg='', title='', img=ICON, HowLong=15, resize=False, L=0 ,T=0 ,W=1280 ,H=720 , TxtColor='0xFFFFFFFF', Font='font14', BorderWidth=10): #HowLong in seconds.
	class MyWindowCountDownWithText(xbmcgui.WindowDialog):
		scr={}; #scr['L']=0; scr['T']=0; scr['W']=1280; scr['H']=720; 
		def __init__(self,msg='',bgArt='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font14',BorderWidth=10):
			self.background=bgArt; self.scr['L']=L; self.scr['T']=T; self.scr['W']=W; self.scr['H']=H; 
			image_path = os.path.join(ART, 'ContentPanel.png')
			self.border = xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'], image_path)
			self.addControl(self.border); 
			self.BG=xbmcgui.ControlImage(self.scr['L']+BorderWidth,self.scr['T']+BorderWidth,self.scr['W']-(BorderWidth*2),self.scr['H']-(BorderWidth*2),self.background,aspectRatio=0, colorDiffuse='0x2FFFFFFF')
			self.addControl(self.BG); 
			#title
			temp = title.replace('[', '<').replace(']', '>')
			temp = re.sub('<[^<]+?>', '', temp)
			title_width = len(str(temp))*11
			self.title=xbmcgui.ControlTextBox(L+(W-title_width)/2,T+BorderWidth,title_width,30,font=Font,textColor='0xFF1E90FF'); 
			self.addControl(self.title); 
			self.title.setText(title);
			#body
			self.TxtMessage=xbmcgui.ControlTextBox(self.scr['L']+BorderWidth,self.scr['T']+30+BorderWidth,self.scr['W']-(BorderWidth*2),self.scr['H']-(BorderWidth*2),font=Font,textColor=TxtColor); 
			self.addControl(self.TxtMessage); 
			self.TxtMessage.setText(msg);
			#timer
			counter_width = (len(continue_msg)-7)*11
			self.counter=xbmcgui.ControlTextBox(L+(W-counter_width)/2,T+H-30-BorderWidth,counter_width,30,font=Font,textColor=TxtColor); 
			self.addControl(self.counter); 
	if resize==False: maxW=1280; maxH=720; W=int(maxW/1.5); H=int(maxH/1.5); L=maxW/6; T=maxH/6; 
	continue_msg = 'Continuing in [B]%d[/B] seconds...'
	TempWindow2=MyWindowCountDownWithText(msg=msg,bgArt=img,L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); 
	StartTime=time.time(); 
	while (time.time()-StartTime) <= HowLong:
		wait = HowLong - (time.time() - StartTime)
		TempWindow2.counter.setText(continue_msg % (wait))
		TempWindow2.show()
		xbmc.sleep(500)
	try: del self.TempWindow2; 
	except: pass

#################################
####### Info Screen	  ########
#################################
# based on H99's & tknorris splash code
ACTION_PREVIOUS_MENU 		    =  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 	        = 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN         = 105	## Mouse wheel down
ACTION_SELECT_ITEM			    =   7	## ?
ACTION_BACKSPACE				= 110	## ?

def InfoScreen(msg='', title='', img=ICON, resize=False, L=0 ,T=0 ,W=1280 ,H=720 , TxtColor='0xFFFFFFFF', Font='font12', BorderWidth=10):
	class MyWindow(xbmcgui.WindowDialog):
		scr={};
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,msg='',bgArt='',L=0,T=0,W=1280,H=720,TxtColor='0xFFFFFFFF',Font='font12',BorderWidth=10):
			self.background=bgArt; self.scr['L']=L; self.scr['T']=T; self.scr['W']=W; self.scr['H']=H; 
			image_path = os.path.join(ART, 'ContentPanel.png')
			self.border = xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'], image_path)
			self.addControl(self.border); 
			self.BG=xbmcgui.ControlImage(self.scr['L']+BorderWidth,self.scr['T']+BorderWidth,self.scr['W']-(BorderWidth*2),self.scr['H']-(BorderWidth*2),self.background,aspectRatio=0, colorDiffuse='0x2FFFFFFF')
			self.addControl(self.BG); 
			#title
			temp = title.replace('[', '<').replace(']', '>')
			temp = re.sub('<[^<]+?>', '', temp)
			title_width = len(str(temp))*11
			self.title=xbmcgui.ControlTextBox(L+(W-title_width)/2,T+BorderWidth,title_width,30,font=Font,textColor='0xFF1E90FF'); 
			self.addControl(self.title); 
			self.title.setText(title);
			#body
			self.TxtMessage=xbmcgui.ControlTextBox(self.scr['L']+BorderWidth,self.scr['T']+30+BorderWidth,self.scr['W']-(BorderWidth*2),self.scr['H']-(BorderWidth*2)-75,font=Font,textColor=TxtColor); 
			self.addControl(self.TxtMessage); 
			self.TxtMessage.setText(msg);
			#buttons
			focus=os.path.join(ART, 'button-focus_lightblue.png'); nofocus=os.path.join(ART, 'button-focus_grey.png');
			self.buttonExit=xbmcgui.ControlButton(L+(W-200)/2,T+H-30-BorderWidth,200,35,"Exit",textColor="0xFF000000",alignment=2,focusTexture=focus,noFocusTexture=nofocus); 
			self.addControl(self.buttonExit); 
			self.buttonExit.controlLeft(self.buttonExit); self.buttonExit.controlRight(self.buttonExit);
			self.setFocus(self.buttonExit);
		def doExit(self): self.CloseWindow1st()
		def onAction(self,action):
			try: F=self.getFocus()
			except: F=False
			if   action == ACTION_PREVIOUS_MENU: self.doExit()
			elif action == ACTION_BACKSPACE: self.doExit()
			elif action == ACTION_NAV_BACK: self.doExit()
			elif action == ACTION_SELECT_ITEM: self.doExit()
			elif action == ACTION_MOVE_UP or action == ACTION_MOUSE_WHEEL_UP: self.TxtMessage.scroll(1)
			elif action == ACTION_MOVE_DOWN or action == ACTION_MOUSE_WHEEL_DOWN: self.TxtMessage.scroll(-1)
			else:
				try: 
					if not F==self.buttonExit: self.setFocus(self.buttonExit); 
				except: pass
		def onControl(self,control):
			if control==self.buttonExit: self.doExit()
			else:
				try: self.setFocus(self.buttonExit)
				except: pass
		def CloseWindow1st(self): self.close()
	if resize==False: maxW=1280; maxH=720; W=int(maxW/1.5); H=int(maxH/1.5); L=maxW/6; T=maxH/6; 
	TempWindow=MyWindow(msg=msg,bgArt=img,L=L,T=T,W=W,H=H,TxtColor=TxtColor,Font=Font,BorderWidth=BorderWidth); 
	TempWindow.doModal()
	del TempWindow

#################################
####### Notification	 ########
#################################
def LogNotify(title,message,times=2000,icon=ICON):
	xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s, False)' % (title , message , times, icon))