import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import popup
import traktit
import datetime

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermath'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
VERSION        = ADDON.getAddonInfo('version')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
REPO           = os.path.join(ADDONS,   'repository.aftermath')
PLAYLISTS      = os.path.join(ADDONS,   'plugin.video.aftermathplaylists')
NEWWIZ         = os.path.join(ADDONS,   'plugin.program.aftermath')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
ADVANCED       = os.path.join(USERDATA, 'advancedsettings.xml')
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   '/resources/art/')
BASEURL        = "http://cb.srfx.in/"
BUILDSURL      = "http://cb.srfx.in/builds/"
INFOURL        = "http://cb.srfx.in/info/"
AFTERMATHXML   = "http://cb.srfx.in/aftermath.xml"
SKIN           = xbmc.getSkinDir()
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
SPLASH         = ADDON.getSetting('splash')
WIZARD         = ADDON.getSetting('wizard')
INSTALLED      = ADDON.getSetting('installed')
EXTRACT        = ADDON.getSetting('extract')
EXTERROR       = ADDON.getSetting('errors')
TODAY          = datetime.date.today()
TOMORROW       = TODAY + datetime.timedelta(days=1)
THREEDAYS      = TODAY + datetime.timedelta(days=3)
SKINCHECK      = ['skin.aftermath.zephyr', 'skin.aftermath.silvo', 'skin.aftermath.simple', 'skin.ccm.aftermath']
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
RAM            = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
TRAKT_EXODUS   = ADDON.getSetting('exodus')
TRAKT_SALTS    = ADDON.getSetting('salts')
TRAKT_ROYALWE  = ADDON.getSetting('royalwe')
TRAKT_VELOCITY = ADDON.getSetting('velocity')
REAL_EXODUS    = ADDON.getSetting('urlresolver')
REAL_URL       = ADDON.getSetting('exodusreal')
KEEP_REAL      = ADDON.getSetting('keepreal')
KEEP_TRAKT     = ADDON.getSetting('keeptrakt')

#################################
####CHECK UPDATE#################
#################################
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
# def updateSettings(name, update=None):
	# if name == 'clear':
		# ADDON.setSetting(id='buildname',      value='')
		# ADDON.setSetting(id='buildversion',   value='')
		# ADDON.setSetting(id='latestversion',  value='')
		# ADDON.setSetting(id='lastbuildcheck', value='')
	# else:
		# update = ADDON.setSetting(id=name, value=update)
	
# def checkBuild(bname,ret):
	# link  = OPEN_URL(AFTERMATHXML).replace('\n','').replace('\r','').replace('\t','')
	# match = re.compile('<build><name>(.+?)</name><version>(.+?)</version><updated>(.+?)</updated><zip>(.+?)</zip><gui>(.+?)</gui><fanart>(.+?)</fanart><icon>(.+?)</icon><welcome>(.+?)</welcome><description>(.+?)</description><change>(.+?)</change></build>').findall(link)
	# for name, version, update, zip, gui, fanart, icon, welcome, description, change in match:
		# if name == bname:
			# if ret=='version':	     return version	
			# elif ret=='update':	     return update	
			# elif ret=='zip':		 return zip	
			# elif ret=='gui':		 return gui	
			# elif ret=='fanart':	     return fanart
			# elif ret=='icon':		 return icon
			# elif ret=='welcome':	 return welcome
			# elif ret=='description': return description
			# elif ret=='change':      return change

# def checkUpdate():
	# BUILDNAME      = ADDON.getSetting('buildname')
	# BUILDVERSION   = ADDON.getSetting('buildversion')
	# version        = checkBuild(BUILDNAME, 'version')
	# ADDON.setSetting('latestversion', version)
	# if version > BUILDVERSION:	
		# yes_pressed = DIALOG.yesno(ADDONTITLE,"New version of your current build avaliable: %s v%s" % (BUILDNAME, version), "Click Go to Build Page to install update.", yeslabel="Go to Build Page", nolabel="Ignore for 3 days")
		# if yes_pressed:
			# url = 'plugin://%s/?mode=14&name=%s' % (ADDON_ID, urllib.quote_plus(BUILDNAME))
			# xbmc.executebuiltin('ActivateWindow(10025 ,%s, return)' % url)
			# ADDON.setSetting('lastbuildcheck', str(TOMORROW))
		# else: 
			# DIALOG.ok(ADDONTITLE, 'You can still update %s to %s from the Aftermath Wizard.' % (BUILDNAME, version))
			# ADDON.setSetting('lastbuildcheck', str(THREEDAYS))

	
# def repoInstall():
	# url = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/repository.aftermath/'
	# link    = OPEN_URL(url+'addon.xml').replace('\n','').replace('\r','').replace('\t','')
	# match   = re.compile('<addon.+?id="repository.aftermath".+?ersion="(.+?)".+?>').findall(link)
	# installzip = 'repository.aftermath-%s.zip' % match[0]
	# if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	# lib=os.path.join(PACKAGES, installzip)
	# try: os.remove(lib)
	# except: pass
	# downloader.download(url+installzip,lib)
	# extract.all(lib, ADDONS)
	# xbmc.sleep(1000)
	# xbmc.executebuiltin('UpdateAddonRepos()')
	# xbmc.executebuiltin('UpdateLocalAddons()')
	# xbmc.sleep(1000)
	
# def playlistInstall():
	# url = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/plugin.video.aftermathplaylists/'
	# link    = OPEN_URL(url+'addon.xml').replace('\n','').replace('\r','').replace('\t','')
	# match   = re.compile('<addon.+?id="plugin.video.aftermathplaylists".+?ersion="(.+?)".+?>').findall(link)
	# installzip = 'plugin.video.aftermathplaylists-%s.zip' % match[0]
	# if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	# lib=os.path.join(PACKAGES, installzip)
	# try: os.remove(lib)
	# except: pass
	# downloader.download(url+installzip,lib)
	# extract.all(lib, ADDONS)
	# xbmc.sleep(1000)
	# xbmc.executebuiltin('UpdateAddonRepos()')
	# xbmc.executebuiltin('UpdateLocalAddons()')
	# xbmc.sleep(1000)
	
def newWizardInstall():
	DIALOG.ok(ADDONTITLE, "Minor changes where made to the wizard file which require it to be redownloaded.", "Please do not cancel the download!")
	url = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/plugin.program.aftermath/'
	link    = OPEN_URL(url+'addon.xml').replace('\n','').replace('\r','').replace('\t','')
	match   = re.compile('<addon.+?id="plugin.program.aftermath".+?ersion="(.+?)".+?>').findall(link)
	installzip = 'plugin.program.aftermath-%s.zip' % match[0]
	if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
	lib=os.path.join(PACKAGES, installzip)
	try: os.remove(lib)
	except: pass
	DP.create(ADDONTITLE, 'Downloading updated wizard!' , '', 'Please Wait')
	downloader.download(url+installzip, lib, DP)
	xbmc.sleep(200)
	DP.update(0,'Installing updated wizard!', '', 'Please Wait')
	extract.all(lib, ADDONS, DP)
	DP.close()
	if os.path.exists(ADDONDATA): shutil.rmtree(ADDONDATA)
	if os.path.exists(PLUGIN): shutil.rmtree(PLUGIN)
	DIALOG.ok(ADDONTITLE, "Kodi needs to be restarted for the new wizard to take affect.", "Please re-launch kodi once its closed")
	xbmc.executebuiltin('Quit()')

# def Splash(name):
	# changeURL = checkBuild(name,'welcome')
	# msg = OPEN_URL(INFOURL+changeURL)
	# title = 'Welcome to %s(v%s)' % (name, checkBuild(name, 'version'))
	# doPopup(title, msg, 'info')
	
# def doPopup(title, msg, type=None, time=1, icon=ICON):
	# if type == 'info': popup.InfoScreen(msg=msg, title=title, BorderWidth=10)
	# elif type == 'notify': popup.LogNotify(ADDONTITLE, msg, time*1000, icon)
	# else: popup.WelcomeScreen(msg=msg, title=title, HowLong=time, BorderWidth=10)
	
# def checkInstalled():
	# current = ''
	# url = 'plugin://%s/?mode=2&name=BuildMenu' % ADDON_ID
	# for skin in SKINCHECK:
		# skinpath = os.path.join(ADDONS,skin)
		# if os.path.exists(skinpath): 
			# current = skin
	# if current == SKINCHECK[0]:
		# yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] Zephyr is currently outdated and is no longer being updated.", "Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
		# if yes_pressed:	xbmc.executebuiltin('ActivateWindow(10025 , %s, return)' % url)
		# else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	# elif current == SKINCHECK[1]:
		# yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] Silvo is currently outdated and is no longer being updated.", "Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
		# if yes_pressed:	xbmc.executebuiltin('ActivateWindow(10025 , %s, return)' % url)
		# else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	# elif current == SKINCHECK[2]:
		# if KODIV >= 16: 
			# gui   = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/',SKINCHECK[2],'settings.xml'))
			# f     = open(gui,mode='r'); g = f.read(); f.close()
			# match = re.compile('<setting id=\"SubSettings.3.Label\" type=\"string\">(.+?)<\/setting>').findall(g)
			# name, build, ver = match[0].replace('[COLOR dodgerblue]','').replace('[/COLOR]','').split(' ')
		# else: 
			# gui   = os.path.join(USERDATA,'guisettings.xml')
			# f     = open(gui,mode='r'); g = f.read(); f.close()
			# match = re.compile('<setting type=\"string\" name=\"skin.aftermath.simple.SubSettings.3.Label\">(.+?)<\/setting>').findall(g)
			# name, build, ver = match[0].replace('[COLOR dodgerblue]','').replace('[/COLOR]','').split(' ')
		# ADDON.setSetting('buildname', 'Aftermath %s' % build)
		# ADDON.setSetting('buildversion', ver[1:])
		# ADDON.setSetting('lastbuildcheck', str(TOMORROW))
		# checkUpdate()
	# elif current == SKINCHECK[3]:
		# yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] CCM is currently outdated and is no longer being updated.", "Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
		# if yes_pressed: xbmc.executebuiltin('ActivateWindow(10025 , %s, return)' % url)
		# else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	# else:
		# yes_pressed = DIALOG.yesno(ADDONTITLE,"Currently no build installed from [COLOR dodgerblue]Aftermath[/COLOR].", "Select 'Build Menu' to install a Community Build", yeslabel="Build Menu", nolabel="Ignore")
		# if yes_pressed:	xbmc.executebuiltin('ActivateWindow(10025 , %s, return)' % url)
		# else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	
# def cleanUp():
	# ADDON.setSetting('installed', 'false')
	# ADDON.setSetting('extract',   '')
	# ADDON.setSetting('errors',    '')
	
# def writeAdvanced():
	# if RAM > 1536: buffer = '209715200'
	# else: buffer = '104857600'
	# with open(ADVANCED, 'w+') as f:
		# f.write('<advancedsettings>\n')
		# f.write('	<network>\n')
		# f.write('		<buffermode>2</buffermode>\n')
		# f.write('		<cachemembuffersize>%s</cachemembuffersize>\n' % buffer)
		# f.write('		<readbufferfactor>5</readbufferfactor>\n')
		# f.write('		<curlclienttimeout>10</curlclienttimeout>\n')
		# f.write('		<curllowspeedtime>10</curllowspeedtime>\n')
		# f.write('	</network>\n')
		# f.write('</advancedsettings>\n')
	# f.close()

if not os.path.exists(NEWWIZ): newWizardInstall()
else:
	if os.path.exists(ADDONDATA): shutil.rmtree(ADDONDATA)
	if os.path.exists(PLUGIN): shutil.rmtree(PLUGIN)
	
#if not os.path.exists(REPO): repoInstall()
#if not os.path.exists(PLAYLISTS): playlistInstall()
#if not os.path.exists(ADVANCED): writeAdvanced()
#if VERSION >= WIZARD: ADDON.setSetting('splash', 'true'); ADDON.setSetting('wizard', VERSION);

#if INSTALLED == 'true':
#	if not EXTRACT == '100' and EXTERROR > 3:
#		yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'Installed: %s / Error Count:%s' % (EXTRACT, EXTERROR), 'Would you like to try again?', nolabel='No Thanks!', yeslabel='Yes Please!')
#		if yes: xbmc.executebuiltin("PlayMedia(plugin://plugin.video.aftermathwiz/?mode=10&name=%s&url=fresh)" % BUILDNAME.replace(' ','+'))
#	elif SKIN not in SKINCHECK:
#		yes=DIALOG.yesno(ADDONTITLE, '%s was not installed correctly!' % BUILDNAME, 'It looks like the skin settings was not applied to the build.', 'Would you like to apply the guiFix?', nolabel='No Thanks!', yeslabel='Yes Please!')
#		if yes: xbmc.executebuiltin("PlayMedia(plugin://plugin.video.aftermathwiz/?mode=10&name=%s&url=gui)" % BUILDNAME.replace(' ','+'))
#	else:
#		Splash(BUILDNAME)
#		traktit.traktit('restore', 'all')
#	cleanUp()
	
#if BUILDCHECK == None or not BUILDCHECK > str(TODAY):
#	if BUILDNAME == "": checkInstalled()
#	else: checkUpdate()
#	ADDON.setSetting('lastbuildcheck', str(TOMORROW))