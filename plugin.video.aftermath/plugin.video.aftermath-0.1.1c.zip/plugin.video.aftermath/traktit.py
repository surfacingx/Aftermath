import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import popup
from addon.common.addon import Addon


USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermath'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
DIALOG         = xbmcgui.Dialog()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
TRAKTFOLD      = os.path.join(ADDONDATA, 'trakt')
TRAKT_EXODUS   = ADDON.getSetting('exodus')
TRAKT_SALTS    = ADDON.getSetting('salts')
TRAKT_ROYALWE  = ADDON.getSetting('royalwe')
TRAKT_VELOCITY = ADDON.getSetting('velocity')
REAL_EXODUS    = ADDON.getSetting('urlresolver')
REAL_URL       = ADDON.getSetting('exodusreal')
KEEP_REAL      = ADDON.getSetting('keepreal')
KEEP_TRAKT     = ADDON.getSetting('keeptrakt')
EXODUS         = 'plugin.video.exodus'
VELOCITY       = 'plugin.video.velocity'
SALT           = 'plugin.video.salts'
ROYALWE        = 'plugin.video.theroyalwe'
URLRESOLVER    = 'script.module.urlresolver'
PATHSALT       = os.path.join(ADDONS, SALT)
PATHEXODUS     = os.path.join(ADDONS, EXODUS)
PATHVELOCITY   = os.path.join(ADDONS, VELOCITY)
PATHROYALWE    = os.path.join(ADDONS, ROYALWE)
PATHURLRES     = os.path.join(ADDONS, URLRESOLVER)

def updateSettings(name, update=None):
	if name == 'clear':
		ADDON.getSetting('exodus',      '')
		ADDON.getSetting('salts',       '')
		ADDON.getSetting('royalwe',     '')
		ADDON.getSetting('velocity',    '')
		ADDON.getSetting('urlresolver', '')
		ADDON.getSetting('exodusreal',  '')
		ADDON.getSetting('keepreal',    'false')
		ADDON.getSetting('keeptrakt',   'false')
	else:
		ADDON.setSetting(name,       update)

def traktit(do, who):
	if who == "all":
		if os.path.exists(PATHEXODUS):    trakt_Exodus(do)
		if os.path.exists(PATHVELOCITY):  trakt_Velocity(do)
		if os.path.exists(PATHSALT):      trakt_Salt(do)
		if os.path.exists(PATHROYALWE):   trakt_TheRoyalWe(do)
		if os.path.exists(PATHURLRES):    real_UrlResolver(do)
	else:
		if who == "exodus"   and os.path.exists(PATHEXODUS):    trakt_Exodus(do)
		if who == "velocity" and os.path.exists(PATHVELOCITY):  trakt_Velocity(do)
		if who == "salt"     and os.path.exists(PATHSALT):      trakt_Salt(do)
		if who == "royalwe"  and os.path.exists(PATHROYALWE):   trakt_TheRoyalWe(do)
		if who == "url"      and os.path.exists(PATHURLRES):    real_UrlResolver(do)
		
def trakt_Salt(do):
	SALTFILE        = os.path.join(TRAKTFOLD, 'salt_trakt')
	SALT_TRAKT      = ['trakt_oauth_token', 'trakt_refresh_token', 'trakt_user']	
	ADD_SALT        = xbmcaddon.Addon(id=SALT)
	TRAKTSALT       = ADD_SALT.getSetting('trakt_user')
	if do == 'update':
		with open(SALTFILE, 'w') as f:
			for trakt in SALT_TRAKT: f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (trakt, ADD_SALT.getSetting(trakt)))
		f.closed
		updateSettings('salt', ADD_SALT.getSetting('trakt_user'))
		popup.LogNotify('SALTS','Trakt Data: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHSALT,'icon.png'))
	elif do == 'restore':
		if os.path.exists(SALTFILE):
			f = open(SALTFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_SALT.setSetting(trakt, value)
				updateSettings('salt', ADD_SALT.getSetting('trakt_user'))
			popup.LogNotify('SALTS','Trakt Data: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHSALT,'icon.png'))
	elif do == 'clear':
		if os.path.exists(SALTFILE): os.remove(SALTFILE)
		f = open(SALTFILE, 'w+'); f.close()
		updateSettings('salt', '')
		popup.LogNotify('SALTS','Trakt Data: [COLOR green]Cleared![/COLOR]', 2000, os.path.join(PATHSALT,'icon.png'))
	xbmc.executebuiltin('Container.Refresh')	
	
def trakt_Exodus(do):
	EXODUSTRAKTFILE = os.path.join(TRAKTFOLD, 'exodus_trakt')
	EXODUSREALFILE  = os.path.join(TRAKTFOLD, 'exodus_real')
	EXODUS_TRAKT    = ['trakt.user', 'trakt.refresh', 'trakt.token']
	EXODUS_REAL     = ['realdebrid.auth', 'realdebrid.id', 'realdebrid.refresh', 'realdebrid.secret', 'realdebrid.token']
	ADD_EXODUS      = xbmcaddon.Addon(id=EXODUS)
	TRAKTEXODUS     = ADD_EXODUS.getSetting('trakt.user')
	REALEXODUS      = ADD_EXODUS.getSetting('realdebrid.id')
	if do == 'update':
		with open(EXODUSTRAKTFILE, 'w') as f:
			for trakt in EXODUS_TRAKT: f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (trakt, ADD_EXODUS.getSetting(trakt)))
		f.closed
		updateSettings('exodus', ADD_EXODUS.getSetting('trakt.user'))
		popup.LogNotify('Exodus','Trakt: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHEXODUS,'icon.png'))
		with open(EXODUSREALFILE, 'w') as f:
			for trakt in EXODUS_REAL: f.write('<real>\n\t<id>%s</id>\n\t<value>%s</value>\n</real>\n' % (trakt, ADD_EXODUS.getSetting(trakt)))
		f.closed
		updateSettings('exodusreal', ADD_EXODUS.getSetting('realdebrid.id'))
		popup.LogNotify('Exodus','Real Debrid: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHEXODUS,'icon.png'))
	elif do == 'restore':
		if os.path.exists(EXODUSTRAKTFILE):
			f = open(EXODUSTRAKTFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_EXODUS.setSetting(trakt, value)
			updateSettings('exodus', ADD_EXODUS.getSetting('trakt.user'))
			popup.LogNotify('Exodus','Trakt: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHEXODUS,'icon.png'))
		if os.path.exists(EXODUSREALFILE):
			f = open(EXODUSREALFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<real><id>(.+?)</id><value>(.+?)</value></real>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_EXODUS.setSetting(trakt, value)
			updateSettings('exodusreal', ADD_EXODUS.getSetting('realdebrid.id'))
			popup.LogNotify('Exodus','Real Debrid: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHEXODUS,'icon.png'))
	elif do == 'clear':
		if os.path.exists(EXODUSFILE): os.remove(EXODUSFILE)
		f = open(EXODUSFILE, 'w+'); f.close()
		updateSettings('exodus', '')
		updateSettings('exodusreal', '')
		popup.LogNotify('Exodus','Trakt and Real Debrid Data: [COLOR green]Cleared![/COLOR]', 2000, os.path.join(PATHEXODUS,'icon.png'))
	xbmc.executebuiltin('Container.Refresh')
	
def trakt_Velocity(do):
	VELOCITYFILE    = os.path.join(TRAKTFOLD, 'velocity_trakt')
	VELO_TRAKT      = ['trakt_authorized', 'trakt_username', 'trakt_oauth_token', 'trakt_refresh_token']
	ADD_VELOCITY    = xbmcaddon.Addon(id=VELOCITY)
	TRAKTVELOCITY   = ADD_VELOCITY.getSetting('trakt_username')
	if do == 'update':
		with open(VELOCITYFILE, 'w') as f:
			for trakt in VELO_TRAKT: f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (trakt, ADD_VELOCITY.getSetting(trakt)))
		f.closed
		updateSettings('velocity', ADD_VELOCITY.getSetting('trakt_username'))
		popup.LogNotify('Velocity','Trakt Data: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHVELOCITY,'icon.png'))
	elif do == 'restore':
		if os.path.exists(VELOCITYFILE):
			f = open(VELOCITYFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_VELOCITY.setSetting(trakt, value)
				updateSettings('velocity', ADD_VELOCITY.getSetting('trakt_username'))
			popup.LogNotify('Velocity','Trakt Data: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHVELOCITY,'icon.png'))
	elif do == 'clear':
		if os.path.exists(VELOCITYFILE): os.remove(VELOCITYFILE)
		f = open(VELOCITYFILE, 'w+'); f.close()
		updateSettings('velocity', '')
		popup.LogNotify('Velocity','Trakt Data: [COLOR green]Cleared![/COLOR]', 2000, os.path.join(PATHVELOCITY,'icon.png'))
	xbmc.executebuiltin('Container.Refresh')
	
def trakt_TheRoyalWe(do):
	ROYALWEFILE     = os.path.join(TRAKTFOLD, 'royalwe_trakt')
	ROYAL_TRAKT     = ['trakt_authorized', 'trakt_account', 'trakt_client_id', 'trakt_oauth_token', 'trakt_refresh_token', 'trakt_secret']
	ADD_ROYALWE     = xbmcaddon.Addon(id=ROYALWE)
	TRAKTROYAL      = ADD_ROYALWE.getSetting('trakt_account')
	if do == 'update':
		with open(ROYALWEFILE, 'w') as f:
			for trakt in ROYAL_TRAKT: f.write('<trakt>\n\t<id>%s</id>\n\t<value>%s</value>\n</trakt>\n' % (trakt, ADD_ROYALWE.getSetting(trakt)))
		f.closed
		updateSettings('royalwe', ADD_ROYALWE.getSetting('trakt_account'))
		popup.LogNotify('The Royal We','Trakt Data: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHROYALWE,'icon.png'))
	elif do == 'restore':
		if os.path.exists(ROYALWEFILE):
			f = open(ROYALWEFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<trakt><id>(.+?)</id><value>(.+?)</value></trakt>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_ROYALWE.setSetting(trakt, value)
				updateSettings('royalwe', ADD_ROYALWE.getSetting('trakt_account'))
			popup.LogNotify('The Royal We','Trakt Data: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHROYALWE,'icon.png'))
	elif do == 'clear':
		if os.path.exists(ROYALWEFILE): os.remove(ROYALWEFILE)
		f = open(ROYALWEFILE, 'w+'); f.close()
		updateSettings('royalwe', '')
		popup.LogNotify('The Royal We','Trakt Data: [COLOR green]Cleared![/COLOR]', 2000, os.path.join(PATHROYALWE,'icon.png'))
	xbmc.executebuiltin('Container.Refresh')
	
def real_UrlResolver(do):
	URLFILE         = os.path.join(TRAKTFOLD, 'url_real')
	URL_REALDEBRID  = ['RealDebridResolver_authorize', 'RealDebridResolver_autopick', 'RealDebridResolver_client_id', 'RealDebridResolver_client_secret', 'RealDebridResolver_enabled', 'RealDebridResolver_priority', 'RealDebridResolver_refresh','RealDebridResolver_token']
	ADD_URLRESOLVER = xbmcaddon.Addon(id=URLRESOLVER)
	REALURL         = ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id')
	if do == 'update':
		with open(URLFILE, 'w') as f:
			for trakt in URL_REALDEBRID: f.write('<real>\n\t<id>%s</id>\n\t<value>%s</value>\n</real>\n' % (trakt, ADD_URLRESOLVER.getSetting(trakt)))
		f.closed
		updateSettings('urlresolver', ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id'))
		popup.LogNotify('URL Resolver','Real Debrid Data: [COLOR green]Saved![/COLOR]', 2000, os.path.join(PATHURLRES,'icon.png'))
	elif do == 'restore':
		if os.path.exists(URLFILE):
			f = open(URLFILE,mode='r'); g = f.read().replace('\n','').replace('\r','').replace('\t',''); f.close();
			match = re.compile('<real><id>(.+?)</id><value>(.+?)</value></real>').findall(g)
			if len(match) > 0:
				for trakt, value in match:
					ADD_URLRESOLVER.setSetting(trakt, value)
				updateSettings('urlresolver', ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id'))
			popup.LogNotify('URL Resolver','Real Debrid Data: [COLOR green]Restored![/COLOR]', 2000, os.path.join(PATHURLRES,'icon.png'))
	elif do == 'clear':
		if os.path.exists(URLFILE): os.remove(URLFILE)
		f = open(URLFILE, 'w+'); f.close()
		updateSettings('urlresolver', '')
		popup.LogNotify('URL Resolver','Real Debrid Data: [COLOR green]Cleared![/COLOR]', 2000, os.path.join(PATHURLRES,'icon.png'))
	xbmc.executebuiltin('Container.Refresh')
	

def activateTrakt(name):
	if name == 'exodus':
		if os.path.exists(PATHEXODUS): url = 'RunPlugin(plugin://plugin.video.exodus/?action=authTrakt)'
		else: DIALOG.ok(ADDONTITLE, 'Exodus is not currently installed.')
	elif name == 'velocity': 
		if os.path.exists(PATHVELOCITY): url = 'RunPlugin(plugin://plugin.video.velocity/?mode=get_pin)'
		else: DIALOG.ok(ADDONTITLE, 'Velocity is not currently installed.')
	elif name == 'salt': 
		if os.path.exists(PATHSALT): url = 'RunPlugin(plugin://plugin.video.salts/?mode=get_pin&amp;sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%5Cplugin.video.salts%5Cfanart.jpg%26_options_sf)'
		else: DIALOG.ok(ADDONTITLE, 'SALTS is not currently installed.')
	elif name == 'royalwe': 
		if os.path.exists(PATHROYALWE): url = 'RunPlugin(plugin://plugin.video.theroyalwe/?mode=authorize_trakt)'
		else: DIALOG.ok(ADDONTITLE, 'The Royal We is not currently installed.')
	xbmc.executebuiltin(url)
	
def activateDebrid(name):
	if name == 'exodus': 
		if os.path.exists(PATHEXODUS): url = 'RunPlugin(plugin://plugin.video.exodus/?action=rdAuthorize)'
		else: DIALOG.ok(ADDONTITLE, 'Exodus is not currently installed.')
	elif name == 'url':
		if os.path.exists(PATHURLRES): 
			ADD_URLRESOLVER.setSetting('RealDebridResolver_authorize', 'true')
			DIALOG.ok(ADDONTITLE, "URL Resolver's RD has been set to Authorized!", "A RD link will be launched to Authorize URLRESOLVER for Real Debrid.","SALT, VELOCITY and a few other addons use URL Resolver.")
			url = 'PlayMedia(&quot;plugin://plugin.video.salts/?rand=1458761975.92&amp;trakt_id=94024&amp;class_url=https%3A%2F%2Fopenload.co%2Fembed%2FQPoazW9t0v8%2F&amp;episode=&amp;mode=resolve_source&amp;class_name=funtastic-vids&amp;season=&amp;direct=False&amp;video_type=Movie&quot;)'
		else: DIALOG.ok(ADDONTITLE, 'URLRESOLVER is not currently installed.')
	xbmc.executebuiltin(url)