import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import popup
import traktit
import datetime
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermath'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = '[B][COLOR dodgerblue]Aftermath[/COLOR] [COLOR white]Wizard[/COLOR][/B]'
VERSION        = ADDON.getAddonInfo('version')
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
HOME           = xbmc.translatePath('special://home/')
ADDONS         = os.path.join(HOME,     'addons')
USERDATA       = os.path.join(HOME,     'userdata')
REPO           = os.path.join(ADDONS,   'repository.aftermath')
PLUGIN         = os.path.join(ADDONS,   ADDON_ID)
PACKAGES       = os.path.join(ADDONS,   'packages')
ADDONDATA      = os.path.join(USERDATA, 'addon_data', ADDON_ID)
TRAKTFOLD      = os.path.join(ADDONDATA, 'trakt')
ADVANCED       = os.path.join(USERDATA, 'advancedsettings.xml')
SOURCES        = os.path.join(USERDATA, 'sources.xml')
FAVOURITES     = os.path.join(USERDATA, 'favourites.xml')
PROFILES       = os.path.join(USERDATA, 'profiles.xml')
CHANHELOG      = os.path.join(PLUGIN,   'changelog.txt')
FANART         = os.path.join(PLUGIN,   'fanart.jpg')
ICON           = os.path.join(PLUGIN,   'icon.png')
ART            = os.path.join(PLUGIN,   'resources', 'art')
TRACKLOG       = os.path.join(PLUGIN,   'resources', 'trakt.txt')
DEBRIDLOG      = os.path.join(PLUGIN,   'resources', 'debrid.txt')
BASEURL        = "http://cb.srfx.in/"
BUILDSURL      = "http://cb.srfx.in/builds/"
INFOURL        = "http://cb.srfx.in/info/"
AFTERMATHXML   = "http://cb.srfx.in/aftermath.xml"
SKIN           = xbmc.getSkinDir()
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
KEEPFAVS       = ADDON.getSetting('keepfavourites')
KEEPSOURCES    = ADDON.getSetting('keepsources')
KEEPPROFILES   = ADDON.getSetting('keepprofiles')
KEEPADVANCED   = ADDON.getSetting('keepadvanced')
TRAKT_EXODUS   = ADDON.getSetting('exodus')
TRAKT_SALTS    = ADDON.getSetting('salt')
TRAKT_ROYALWE  = ADDON.getSetting('royalwe')
TRAKT_VELOCITY = ADDON.getSetting('velocity')
REAL_EXODUS    = ADDON.getSetting('urlresolver')
REAL_URL       = ADDON.getSetting('exodusreal')
KEEP_REAL      = ADDON.getSetting('keepreal')
KEEP_TRAKT     = ADDON.getSetting('keeptrakt')
TODAY          = datetime.date.today()
NEXTCHECK      = TODAY - datetime.timedelta(days=3)
EXCLUDES       = ['script.module.addon.common','repository.aftermath','plugin.video.aftermathplaylists','plugin.video.aftermath','plugin.video.aftermathwiz']
BUILDS         = ['Aftermath Simple']
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
RAM            = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
EXODUS         = 'plugin.video.exodus'
VELOCITY       = 'plugin.video.velocity'
SALT           = 'plugin.video.salts'
ROYALWE        = 'plugin.video.theroyalwe'
URLRESOLVER    = 'script.module.urlresolver'
PATHSALT       = os.path.join(ADDONS, SALT)
PATHEXODUS     = os.path.join(ADDONS, EXODUS)
PATHVELOCITY   = os.path.join(ADDONS, VELOCITY)
PATHROYALWE    = os.path.join(ADDONS, ROYALWE)
PATHURLRES     = os.path.join(ADDONS, URLRESOLVER)

#################################
####### MENUS ###################
#################################

def index():
	if BUILDNAME=='':
		addDir('Aftermath: No Build Installed','none',2)	
	else:
		vcheck = checkBuild(BUILDNAME,'version')
		if vcheck > BUILDVERSION: msg = '%s(v%s) - [COLOR red][B]NEW UPDATE: v%s[/B][/COLOR]' % (BUILDNAME, BUILDVERSION, vcheck)
		else: msg = '%s(v%s)' % (BUILDNAME, BUILDVERSION)
		addDir(msg,BUILDNAME,14)	
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addDir('Aftermath Builds','BuildList',2, icon=os.path.join(ART,'builds.png'))
	addFile('Aftermath Playlists','Playlists',3, icon=os.path.join(ART,'playlist.png'))
	addDir('Aftermath Maintenance','Maintenance',4, icon=os.path.join(ART,'maintenance.png'))
	addDir('Aftermath Guides','Guides',18, icon=os.path.join(ART,'guides.png'))
	addFile('Aftermath Info','wizard',6, icon=os.path.join(ART,'info.png'))
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	#addFile('Aftermath Addons List','Addons',16)
	addFile('Aftermath Settings','Settings',13, icon=os.path.join(ART,'settings.png'))
	setView('movies', 'MAIN')
	
def guideMenu():
	addFile('[I]Guides to help setup different accounts.[/I]')
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addDir('Aftermath Settings Up Trakt','trakt',19)
	addDir('Aftermath Settings Up Real Debrid','trakt',22)
	setView('movies', 'MAIN')
	
def traktMenu():
	addFile('[I]Register FREE Account at http://trakt.tv [/I]')
	addFile('Aftermath Trakt Info','trakt','6','',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	if not os.path.exists(PATHEXODUS): addFile('[COLOR red]Exodus: Not Installed[/COLOR]')
	elif TRAKT_EXODUS == "": addFile('[COLOR red]Exodus: Not Registered[/COLOR]','exodus',20)
	else: addFile('[COLOR green]Exodus: %s[/COLOR]' % TRAKT_EXODUS,'exodus',20)
	if not os.path.exists(PATHVELOCITY): addFile('[COLOR red]Velocity: Not Installed[/COLOR]')
	elif TRAKT_VELOCITY == "": addFile('[COLOR red]Velocity: Not Registered[/COLOR]','velocity',20)
	else: addFile('[COLOR green]Velocity: %s[/COLOR]' % TRAKT_VELOCITY,'velocity',20)
	if not os.path.exists(PATHSALT): addFile('[COLOR red]Salt: Not Installed[/COLOR]')
	elif TRAKT_SALTS == "": addFile('[COLOR red]Salt: Not Registered[/COLOR]','salt',20)
	else: addFile('[COLOR green]Salt: %s[/COLOR]' % TRAKT_SALTS,'salt',20)
	if not os.path.exists(PATHROYALWE): addFile('[COLOR red]Royal We: Not Installed[/COLOR]')
	elif TRAKT_ROYALWE == "": addFile('[COLOR red]Royal We: Not Registered[/COLOR]','royalwe',20)
	else: addFile('[COLOR green]Royal We: %s[/COLOR]' % TRAKT_ROYALWE,'royalwe',20)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addFile('Aftermath Save Trakt & Real Debrid Data','update',21, 'all')
	addFile('Aftermath Recover Trakt & Real Debrid Data','restore',21, 'all')
	setView('movies', 'MAIN')
	
def debridMenu():
	addFile('[I]Register A Premium Account at http://real-debrid.com (Paid $20/180days)[/I]')
	addFile('Aftermath Real Debrid Info','realdebrid','6')
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	if not os.path.exists(PATHEXODUS): addFile('[COLOR red]Exodus: Not Installed[/COLOR]')
	elif REAL_EXODUS == "": addFile('[COLOR red]Exodus: Not Registered[/COLOR]','exodus',23)
	else: addFile('[COLOR green]Exodus: %s[/COLOR]' % REAL_EXODUS,'exodus',23)
	if not os.path.exists(PATHURLRES): addFile('[COLOR red]URL Resolver: Not Installed[/COLOR]')
	elif REAL_URL == "": addFile('[COLOR red]URL Resolver: Not Registered[/COLOR]','url',23)
	else: addFile('[COLOR green]URL Resolver: %s[/COLOR]' % REAL_URL,'url',23)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addFile('Aftermath Save Trakt & Real Debrid Data','update',21,'all')
	addFile('Aftermath Recover Trakt & Real Debrid Data','restore',21,'all')
	setView('movies', 'MAIN')
	
def buildMenu():
	addFile('Aftermath Kodi v%s Build Info' % str(KODIV),'builds',6, icon=os.path.join(ART,'info.png'))
	addFile('[COLOR dodgerblue]==================================================[/COLOR]')
	addDir('Aftermath Simple (v%s)' % checkBuild('Aftermath Simple','version'),'Aftermath Simple',14)
	setView('movies', 'MAIN')

def maintenance():
	addFile('Aftermath Clear Cache','Clean Cache',7)
	addFile('Aftermath Fresh Start','Fresh Start',8)
	addFile('Aftermath Clear Packages','Clear Packages',9)
	addFile('Aftermath Force Updates','Force Updates',17)
	setView('movies', 'MAIN')
	
def viewBuild(name,url):
	vcheck = checkBuild(name, 'version')
	if name == BUILDNAME and vcheck > BUILDVERSION: msg = '%s(v%s) - [COLOR red][B]NEW UPDATE(Current: v%i)[/B][/COLOR]' %(BUILDNAME, vcheck, BUILDVERSION)
	else: msg = '%s(v%s)' % (name, vcheck)
	addFile(msg,name,15)
	addFile('[COLOR dodgerblue]==============[ Install Options ]=======================[/COLOR]')
	addFile('Aftermath Clean Install - [I](Recommended)[/I]',name,10,'fresh')
	addFile('Aftermath Normal Install',name,10,'normal')
	addFile('Aftermath Apply guisettings.xml fix',name,10,'gui')
	addFile('[COLOR dodgerblue]==============[ Information ]=========================[/COLOR]')
	addFile('Aftermath Build Description','description',12,name)
	addFile('Aftermath Change Log','change',12,name)
	setView('movies', 'MAIN')	

#################################
####CHECK UPDATE#################
#################################
	
def checkBuild(bname,ret):
	link  = OPEN_URL(AFTERMATHXML).replace('\n','').replace('\r','').replace('\t','')
	match = re.compile('<build><name>(.+?)</name><version>(.+?)</version><updated>(.+?)</updated><zip>(.+?)</zip><gui>(.+?)</gui><fanart>(.+?)</fanart><icon>(.+?)</icon><welcome>(.+?)</welcome><description>(.+?)</description><change>(.+?)</change></build>').findall(link)
	for name, version, update, zip, gui, fanart, icon, welcome, description, change in match:
		if name == bname:
			if ret=='version':	     return version	
			elif ret=='update':	     return update	
			elif ret=='zip':		 return zip	
			elif ret=='gui':		 return gui	
			elif ret=='gui16':	     return gui16
			elif ret=='fanart':	     return fanart
			elif ret=='icon':		 return icon
			elif ret=='welcome':	 return welcome
			elif ret=='description': return description
			elif ret=='change':      return change

def updateSettings(name, update=None):
	if name == 'clear':
		ADDON.setSetting(id='buildname',	  value='')
		ADDON.setSetting(id='buildversion',   value='')
		ADDON.setSetting(id='latestversion',  value='')
		ADDON.setSetting(id='lastbuildcheck', value='')
	else:
		update = ADDON.setSetting(id=name, value=update)
	
def checkUpdate():
	vcheck = checkBuild(BUILDNAME,'version')
	if vcheck > BUILDVERSION: 
		yes=DIALOG.yesno('There is an updated version of %s: v%s' % (BUILDNAME, vcheck), 'Would you like to do a fresh install of it?', nolabel='No Thanks!',yeslabel='Yes Update!')
		if yes: buildWizard(BUILDNAME, 'fresh')
		else: DIALOG.ok(ADDONTITLE, 'You can still update %s from %s to %s from the %s.' (BUILDNAME, BUILDVERSION, vcheck, ADDONTITLE))
	else: DIALOG.ok(ADDONTITLE, 'You are currently running the newest version:', '%s (v%s)' % (BUILDNAME, BUILDVERSION))
	
def forceUpdate():
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	popup.LogNotify(ADDONTITLE, 'Forcing Check Updates')
	
#################################
####VIEW LOG#####################
#################################
	
def viewLog(name,type):
	changeURL = checkBuild(name,type)
	link = OPEN_URL(INFOURL+changeURL)
	title = '%s - %s: (v%s)' % (ADDONTITLE, name, checkBuild(name,'version'))
	#TextBoxes(title, link)
	doPopup(title, link, 'info')

def info(display):
	if display=='builds': msg = 'Here are a list of builds offered in the wizard and a small description, for more information on the build then click on the description or change log in the build menu.\n\n[COLOR dodgerblue]Aftermath Simple(v'+checkBuild('Aftermath Simple','version')+')[/COLOR]: Light weight build using CCM Helix skin.  Only the top addons are included without alot of the extra stuff, primarily for Fire TV Sticks.\n\n[COLOR dodgerblue]Aftermath Simple Lite[/COLOR]: This custom build has been discontinued.\n\n[COLOR dodgerblue]Aftermath CCM[/COLOR]: This custom build has been discontinued.'
	elif display=='wizard': f = open(CHANHELOG,mode='r'); change = f.read(); f.close(); msg = 'Welcome to the home of the Aftermath Custom Builds.  You can install the latest version of our builds with ease and get notifications when updates have been released.  Also you can download addon packs that contain various addons.\n\nCheck http://srfx.in for latest guides and tutorials.\n\nAftermath Wizard Change Log:\n\n%s' % change
	elif display=='trakt': f = open(TRACKLOG,mode='r'); msg = f.read(); f.close()
	elif display=='realdebrid': f = open(DEBRIDLOG,mode='r'); msg = f.read(); f.close()
	#TextBoxes(ADDONTITLE, msg)
	doPopup(ADDONTITLE, msg, 'info')
	
def Splash(name):
	changeURL = checkBuild(name,'welcome')
	msg = OPEN_URL(INFOURL+changeURL)
	title = 'Welcome to %s(v%s)' % (name, checkBuild(name, 'version'))
	doPopup(title, msg, 'timer', 30)
	
def doPopup(title, msg, type=None, time=1, icon=ICON):
	if type == 'info': popup.InfoScreen(msg=msg, title=title, BorderWidth=10)
	elif type == 'notify': popup.LogNotify(ADDONTITLE, msg, time*1000, icon)
	else: popup.WelcomeScreen(msg=msg, title=title, HowLong=time, BorderWidth=10)
	
def addonList():
	dirs = os.listdir(ADDONS)
	vid = None; prog = None; repo = None; audio = None;
	for file in dirs:
		addon = xbmc.translatePath(os.path.join('special://home/addons/',file,'addon.xml'))
		if os.path.exists(addon): 
			xml = open(addon,mode='r')
			g = xml.read().replace('\n','').replace('\r','')
			xml.close()
			match = re.compile('<addon *.+?ame="(.+?)".+?>').findall(g)
			title = match[0]
			type = re.compile('<provides>(.+?)</provides>').findall(g)
			if len(type) > 0: type2 = type[0].split(' '); 
			else: type2 = ''
			if 'executable' in type2: 
				if not prog == None: prog += ', '+title
				else: prog = title
			elif 'audio' in type2: 
				if not audio == None: audio += ', '+title
				else: audio = title
			elif 'video' in type2: 
				if not vid == None: vid += ', '+title
				else: vid = title
			elif file[:11] == 'repository.': 
				if not repo == None: repo += ', '+title
				else: repo = title
	with open(os.path.join(ADDONDATA,'AddonsList.txt'), 'w') as f:
		f.write('[COLOR yellow][B]Author:[/B][/COLOR] [COLOR dodgerblue][B]Aftermath[/B][/COLOR]                    [COLOR yellow][B]Last Update:[/B][/COLOR] %s                    [COLOR yellow][B]Adult Content:[/B][/COLOR] No\n\n' % str(TODAY))
		f.write('[COLOR yellow][B]Description:[/B][/COLOR]\n\n')
		f.write('[COLOR yellow][B]Skin:[/B][/COLOR]\n\n')
		f.write('[COLOR yellow][B]Video Addons:[/B][/COLOR] %s\n\n' % vid)
		f.write('[COLOR yellow][B]Audio Addons:[/B][/COLOR] %s\n\n' % audio)
		f.write('[COLOR yellow][B]Program Addons:[/B][/COLOR] %s\n\n' % prog)
		f.write('[COLOR yellow][B]Repositories:[/B][/COLOR] %s\n\n' % repo)
	f.close()
	
#################################
####BUILD/ADDON INSTALL##########
#################################

def buildWizard(name, type):
	if type == 'gui':
		if name != BUILDNAME:
			DIALOG.ok(ADDONTITLE, "%s community build is not currently installed." % name, "Please install the build before doing a guiFix.")
		else:
			yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to apply the guifix for:', '%s?' % name, nolabel='No, Cancel',yeslabel='Yes, Apply Fix')
			if yes_pressed:
				buildzip = BUILDSURL+checkBuild(name,'gui')
				if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
				DP.create(ADDONTITLE,'Downloading %s GuiFix' % name,'', 'Please Wait')
				lib=os.path.join(PACKAGES, '%s.zip' % name)
				try: os.remove(lib)
				except: pass
				downloader.download(buildzip, lib, DP)
				time.sleep(2)
				DP.update(0,"", "Installing %s" % name)
				extract.all(lib,USERDATA,DP)
				killxbmc()
	elif type == 'fresh':
		freshStart(params)
	elif type == 'normal':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to install:', '%s v%s?' % (name, checkBuild( name,'version')), nolabel='No, Cancel',yeslabel='Yes, Install')
		if yes_pressed:
			buildzip = BUILDSURL+checkBuild(name,'zip')
			if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
			DP.create(ADDONTITLE,'Downloading %s ' % name,'', 'Please Wait')
			lib=os.path.join(PACKAGES, '%s.zip' % name)
			try: os.remove(lib)
			except: pass
			downloader.download(buildzip, lib, DP)
			time.sleep(2)
			DP.update(0,"", "Installing "+name)
			ext = extract.all(lib,HOME,DP)
			percent, errors, error = ext.split('/');updateSettings('buildname', name); updateSettings('buildversion', checkBuild( name,'version')); updateSettings('latestversion', checkBuild( name,'version')); updateSettings('lastbuildcheck', str(TODAY)); updateSettings('installed', 'true'); updateSettings('extract', str(percent)); updateSettings('errors', str(errors))
			print 'INSTALLED %s: [ERRORS:%s] %s' % (percent, errors, error)
			if not error == 'None':
				yes=DIALOG.yesno(ADDONTITLE, 'INSTALLED %s: [ERRORS:%s]' % (percent, errors), 'Would you like to view the errors?', nolabel='No, Cancel',yeslabel='Yes, View')
				if yes:
					doPopup(ADDONTITLE, error, 'info')
			DIALOG.ok(ADDONTITLE, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
			killxbmc()
	
################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def deletePackages(url):
	if os.path.exists(PACKAGES):
		try:	
			for root, dirs, files in os.walk(PACKAGES):
				file_count = 0
				file_count += len(files)
				# Count files and give option to delete
				if file_count > 0:
					if DIALOG.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
						for f in files:	os.unlink(os.path.join(root, f))
						for d in dirs: shutil.rmtree(os.path.join(root, d))
						popup.LogNotify(ADDONTITLE,'Clear Packages: [COLOR green]Success[/COLOR]!')
				else: popup.LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]None Found![/COLOR]')
		except: popup.LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]Error[/COLOR]!')
	else: popup.LogNotify(ADDONTITLE,'Clear Packages: [COLOR red]None Found![/COLOR]')

#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
	
def deleteCacheFiles(url):
	print '############################################################	   DELETING STANDARD CACHE			 ###############################################################'
	xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
	if os.path.exists(xbmc_cache_path)==True:	
		for root, dirs, files in os.walk(xbmc_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files:
						try: os.unlink(os.path.join(root, f))
						except: pass
					for d in dirs:
						try: shutil.rmtree(os.path.join(root, d))
						except: pass
			else: pass

	if xbmc.getCondVisibility('system.platform.ATV2'):
		atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
		for root, dirs, files in os.walk(atv2_cache_a):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass
		atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
		for root, dirs, files in os.walk(atv2_cache_b):
			file_count = 0
			file_count += len(files)
			if file_count > 0:
				if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass
	# Set path to Cydia Archives cache files
	# Set path to What th Furk cache files
	wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
	if os.path.exists(wtf_cache_path)==True:	
		for root, dirs, files in os.walk(wtf_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass				
	# Set path to 4oD cache files
	channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
	if os.path.exists(channel4_cache_path)==True:	
		for root, dirs, files in os.walk(channel4_cache_path):
			file_count = 0
			file_count += len(files)		
			# Count files and give option to delete
			if file_count > 0:	
				if DIALOG.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass
				
	# Set path to BBC iPlayer cache files
	iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
	if os.path.exists(iplayer_cache_path)==True:	
		for root, dirs, files in os.walk(iplayer_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:	
				if DIALOG.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass			
				
	# Set path to Simple Downloader cache files
	downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
	if os.path.exists(downloader_cache_path)==True:	
		for root, dirs, files in os.walk(downloader_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass
				
	# Set path to ITV cache files
	itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
	if os.path.exists(itv_cache_path)==True:	
		for root, dirs, files in os.walk(itv_cache_path):
			file_count = 0
			file_count += len(files)		
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass

	# Set path to temp cache files
	temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
	if os.path.exists(temp_cache_path)==True:	
		for root, dirs, files in os.walk(temp_cache_path):
			file_count = 0
			file_count += len(files)
			# Count files and give option to delete
			if file_count > 0:
				if DIALOG.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
					for f in files: os.unlink(os.path.join(root, f))
					for d in dirs: shutil.rmtree(os.path.join(root, d))
			else: pass
	popup.LogNotify(ADDONTITLE,'Clear Cache: [COLOR green]Success![/COLOR]')
 
def OPEN_URL(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', USER_AGENT)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def launchPlaylists():
	plug = 'plugin.video.aftermathplaylists'
	playlist = os.path.join(ADDONS, plug)
	if os.path.exists(playlist):
		xbmc.executebuiltin('RunAddon(%s)' % plug)
	else: 
		url = 'https://raw.githubusercontent.com/surfacingx/Aftermath/master/plugin.video.aftermathplaylists/'
		link    = OPEN_URL(url+'addon.xml').replace('\n','').replace('\r','').replace('\t','')
		match   = re.compile('<addon.+?id="plugin.video.aftermathplaylists".+?ersion="(.+?)".+?>').findall(link)
		playlistzip = 'plugin.video.aftermathplaylists-%s.zip' % match[0]
		if not os.path.exists(PACKAGES): os.makedirs(PACKAGES)
		lib=os.path.join(path, playlistzip)
		try: os.remove(lib)
		except: pass
		downloader.download(url+playlistzip,lib)
		extract.all(lib, ADDONS)
		xbmc.sleep(1000)
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		xbmc.sleep(1000)

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
	choice = DIALOG.yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
	if choice == 0:
		return
	elif choice == 1:
		pass
	myplatform = platform()
	print "Platform: " + str(myplatform)
	if myplatform == 'osx': # OSX
		print "############   try osx force close  #################"
		try: os.system('killall -9 XBMC')
		except: pass
		try: os.system('killall -9 Kodi')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'linux': #Linux
		print "############   try linux force close  #################"
		try: os.system('killall XBMC')
		except: pass
		try: os.system('killall Kodi')
		except: pass
		try: os.system('killall -9 xbmc.bin')
		except: pass
		try: os.system('killall -9 kodi.bin')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
	elif myplatform == 'android': # Android  
		print "############   try android force close  #################"
		try: os.system('adb shell am force-stop org.xbmc.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.kodi')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc.xbmc')
		except: pass
		try: os.system('adb shell am force-stop org.xbmc')
		except: pass		
		DIALOG.ok("[COLOR=yellow][B]TO COMPLETE AFTERMATH INSTALL[/COLOR][/B]", "Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
	elif myplatform == 'windows': # Windows
		print "############   try windows force close  #################"
		try:
			os.system('@ECHO off')
			os.system('tskill XBMC.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('tskill Kodi.exe')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im Kodi.exe /f')
		except: pass
		try:
			os.system('@ECHO off')
			os.system('TASKKILL /im XBMC.exe /f')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
	else: #ATV
		print "############   try atv force close  #################"
		try: os.system('killall AppleTV')
		except: pass
		print "############   try raspbmc force close  #################" #OSMC / Raspbmc
		try: os.system('sudo initctl stop kodi')
		except: pass
		try: os.system('sudo initctl stop xbmc')
		except: pass
		DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")	

##########################
###DETERMINE PLATFORM#####
##########################
		
def platform():
	if   xbmc.getCondVisibility('system.platform.android'): return 'android'
	elif xbmc.getCondVisibility('system.platform.linux'):   return 'linux'
	elif xbmc.getCondVisibility('system.platform.windows'): return 'windows'
	elif xbmc.getCondVisibility('system.platform.osx'):	    return 'osx'
	elif xbmc.getCondVisibility('system.platform.atv2'):    return 'atv2'
	elif xbmc.getCondVisibility('system.platform.ios'):	    return 'ios'
	
############################
###FRESH START##############
############################

def percentage(part, whole):
  return 100 * float(part)/float(whole)

def freshStart(params):
	fname = str(params['name']).replace('+',' ')
	fmode = str(params['mode'])
	xbmc.log("freshstart.main_list %s" % repr(params))
	if SKIN != 'skin.confluence': DIALOG.ok(ADDONTITLE, "Please set the default skin back to 'Confluence'", "Before doing a fresh install!", "Press the back button to return to this menu after changing skin."); xbmc.executebuiltin("ActivateWindow(appearancesettings,return)")
	else:
		if fmode == '10': yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings", "Before installing "+fname+"?", nolabel='No, Cancel',yeslabel='Yes, Continue')
		else: yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings?", nolabel='No, Cancel',yeslabel='Yes, Continue')
		if yes_pressed:
			#addonPath=xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path')
			#addonPath=xbmc.translatePath(addonPath)
			#xbmcPath=os.path.join(addonPath,"..","..")
			xbmcPath=os.path.abspath(HOME)
			xbmc.log("freshstart.main_list xbmcPath=%s" % xbmcPath); failed=False
			DP.create(ADDONTITLE,"Clearing all files and folders:",'', '')
			total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0;
			try:
				for root, dirs, files in os.walk(xbmcPath,topdown=True):
					dirs[:] = [d for d in dirs if d not in EXCLUDES]
					for name in files:
						del_file += 1
						fold = root.split('\\')
						x = len(fold)-1
						if name == 'sources.xml' and fold[x] == 'userdata' and KEEPSOURCES == 'true': xbmc.log("Keep Sources: %s\\%s" % (root, name))
						elif name == 'favourites.xml' and fold[x] == 'userdata' and KEEPFAVS == 'true': xbmc.log("Keep Favourites: %s\\%s" % (root, name))
						elif name == 'profiles.xml' and fold[x] == 'userdata' and KEEPPROFILES == 'true': xbmc.log("Keep Profiles: %s\\%s" % (root, name))
						elif name == 'advancedsettings.xml' and fold[x] == 'userdata' and KEEPADVANCED == 'true':  xbmc.log("Keep Advanced Settings: %s\\%s" % (root, name))
						else:
							DP.update(int(percentage(del_file, total_files)), '', 'File: [COLOR yellow]%s[/COLOR]' % name, '')
							try: os.remove(os.path.join(root,name))
							except:
								if name not in ["Addons19.db","MyVideos93.db","Textures13.db","kodi.log"]: failed=True
								xbmc.log("Error removing %s\\%s" % (root, name))
				for root, dirs, files in os.walk(xbmcPath,topdown=True):
					dirs[:] = [d for d in dirs if d not in EXCLUDES]							
					for name in dirs:
						DP.update(100, '', 'Cleaning Up Empty Folder: [COLOR yellow]%s[/COLOR]' % name, '')
						if name not in ["Database","userdata","addons","addon_data"]:
							shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
				DP.close()
				updateSettings('clear')
				if not failed: xbmc.log("freshstart.main_list All user files removed, you now have a clean install")
				else: xbmc.log("freshstart.main_list User files partially removed")
				if fmode == '10': 
					DIALOG.ok(ADDONTITLE, "Your current setup for kodi has been cleared!", "Now we will install: %s v%s" % (fname, checkBuild(fname,'version')))
					buildWizard(fname, 'normal')
				else: 
					DIALOG.ok(ADDONTITLE, "The process is complete, you're now back to a fresh Kodi configuration with Aftermath Wizard","Please reboot your system or restart Kodi in order for the changes to be applied.")
					ADDON.setSetting('installed', 'false')
					ADDON.setSetting('extract', '')
					ADDON.setSetting('errors', '')
					killxbmc()
			except: 
				DIALOG.ok(ADDONTITLE,"Problem found","Your settings has not been changed")
				import traceback
				xbmc.log(traceback.format_exc())
				xbmc.log("freshstart.main_list NOT removed")
		else: popup.LogNotify(ADDONTITLE,'Fresh Install: [COLOR red]Cancelled![/COLOR]'); xbmc.executebuiltin('Container.Refresh')
	
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleaneDParams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleaneDParams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param

def addDir(display,name=None,mode=None,url=None,fanart=FANART,icon=ICON):
		u=sys.argv[0]
		if not mode == None: u += "?mode="+str(mode)
		if not name == None: u += "&name="+urllib.quote_plus(name)
		if not url == None: u += "&url="+urllib.quote_plus(url)
		ok=True
		display = '[B][COLOR white]%s[/COLOR][/B]' % display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
		liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
		liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
		liz.setProperty( "Fanart_Image", fanart )
	 	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		
def addFile(display,name=None,mode=None,url=None,fanart=FANART,icon=ICON):
		u=sys.argv[0]
		if not mode == None: u += "?mode="+str(mode)
		if not name == None: u += "&name="+urllib.quote_plus(name)
		if not url == None: u += "&url="+urllib.quote_plus(url)
		ok=True
		display = '[B][COLOR white]%s[/COLOR][/B]' % display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
		liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=icon)
		liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
		liz.setProperty( "Fanart_Image", fanart )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

		
params=get_params()
url=None
name=None
mode=None

try:	 url=urllib.unquote_plus(params["url"])
except:  pass
try:	 name=urllib.unquote_plus(params["name"])
except:  pass
try:	 mode=int(params["mode"])
except:  pass
		
print '%s: %s' % (ADDONTITLE, VERSION)
print "Mode: %s" % mode
print "Name: %s" % name
print "Url: %s" % url

def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
		
if mode==None: index()
elif mode==2:  buildMenu()
elif mode==3:  launchPlaylists()
elif mode==4:  maintenance()
elif mode==5:  checkBuild('display','all', '')
elif mode==6:  info(name)		
elif mode==7:  deleteCacheFiles(url)
elif mode==8:  freshStart(params)
elif mode==9:  deletePackages(url)
elif mode==10: buildWizard(name,url)
elif mode==11: checkUpdate()
elif mode==12: viewLog(url,name)
elif mode==13: ADDON.openSettings()
elif mode==14: viewBuild(name,url)
elif mode==15: Splash(name)
elif mode==16: addonList()
elif mode==17: forceUpdate()
elif mode==18: guideMenu()
elif mode==19: traktMenu()
elif mode==20: traktit.activateTrakt(name)
elif mode==21: traktit.traktit(name, url)
elif mode==22: debridMenu()
elif mode==23: traktit.activateDebrid(name)
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))