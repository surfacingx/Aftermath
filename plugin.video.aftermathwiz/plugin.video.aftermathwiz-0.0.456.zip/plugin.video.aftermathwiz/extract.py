import zipfile, xbmcgui

DIALOG         = xbmcgui.Dialog()

def all(_in, _out, dp = None):
	if not dp:
		return allNoProgress(_in, _out)
	else:
		return allWithProgress(_in, _out, dp)

def allNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        print str(e)
        return False
    return True

def allWithProgress(_in, _out, dp):
    zin = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0
    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update), str(item))
            zin.extract(item, _out)
			print str(item)
    except Exception, e:
        print str(e)
        return False
    return True