import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import time
import plugintools
import datetime
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net


USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathwiz'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = 'Aftermath Wizard'
DIALOG         = xbmcgui.Dialog()
BASEURL        = "http://cb.srfx.in/builds/"
BASEURLLOG     = BASEURL+'info/'
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('buildlatestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
TODAY          = datetime.date.today()
NEXTCHECK      = TODAY - datetime.timedelta(days=3)

#################################
####CHECK UPDATE#################
#################################
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
if BUILDNAME != "" and BUILDCHECK <= str(NEXTCHECK):
	link = OPEN_URL(BASEURLLOG+'version.txt').replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?ersion="(.+?)".+?ype="(.+?)".+?ate="(.+?)".+?ip="(.+?)".+?ui="(.+?)".+?escription="(.+?)".+?hange="(.+?)"').findall(link)
	for name,version,type,date,zip,gui,description,change in match:
		if name == BUILDNAME and version > BUILDVERSION:
			yes_pressed = plugintools.message_yes_no(ADDONTITLE,"New version of your current build avaliable:", "Click Yes to go to page.")
			if yes_pressed:
				url = 'plugin://'+ADDON_ID+'/?mode=14&name='+urllib.quote_plus(name)+'&url='+zip
				xbmc.executebuiltin('ActivateWindow(10025 ,'+url+', return)')
				
	ADDON.setSetting('lastbuildcheck', str(TODAY))