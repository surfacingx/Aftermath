import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
import plugintools
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net


USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathwiz'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = 'Aftermath Wizard'
DIALOG         = xbmcgui.Dialog()
REPO           = xbmc.translatePath(os.path.join('special://home/addons','repository.aftermath'))
ADVANCED       = xbmc.translatePath(os.path.join('special://home/userdata','advancedsettings.xml'))
BASEURL        = "http://cb.srfx.in/builds/"
BASEURLLOG     = BASEURL+'info/'
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
TODAY          = datetime.date.today()
NEXTCHECK      = TODAY - datetime.timedelta(days=3)
SKINCHECK      = ['skin.aftermath.zephyr', 'skin.aftermath.silvo', 'skin.aftermath.simple', 'skin.ccm.aftermath']
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
RAM            = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
EXODUS         = 'plugin.video.exodus'
VELOCITY       = 'plugin.video.velocity'
SALT           = 'plugin.video.salts'
ROYALWE        = 'plugin.video.theroyalwe'
URLRESOLVER    = 'script.module.urlresolver'
EXODUS_TRAKT   = ['realdebrid.auth', 'realdebrid.id', 'realdebrid.refresh', 'realdebrid.secret', 'realdebrid.token', 'trakt.user', 'trakt.refresh', 'trakt.token']
VELO_TRAKT     = ['trakt_authorized', 'trakt_username', 'trakt_oauth_token', 'trakt_refresh_token']
SALT_TRAKT     = ['trakt_oauth_token', 'trakt_refresh_token', 'trakt_user']
ROYAL_TRAKT    = ['trakt_authorized', 'trakt_account', 'trakt_client_id', 'trakt_oauth_token', 'trakt_refresh_token', 'trakt_secret']
URL_REALDEBRID = ['RealDebridResolver_authorize', 'RealDebridResolver_autopick', 'RealDebridResolver_client_id', 'RealDebridResolver_client_secret', 'RealDebridResolver_enabled', 'RealDebridResolver_priority', 'RealDebridResolver_refresh','RealDebridResolver_token']
PATHEXODUS     = xbmc.translatePath(os.path.join('special://home/addons/',EXODUS))
PATHVELOCITY   = xbmc.translatePath(os.path.join('special://home/addons/',VELOCITY))
PATHSALT       = xbmc.translatePath(os.path.join('special://home/addons/',SALT))
PATHROYALWE    = xbmc.translatePath(os.path.join('special://home/addons/',ROYALWE))
PATHURLRES     = xbmc.translatePath(os.path.join('special://home/addons/',URLRESOLVER))
if os.path.exists(PATHEXODUS): ADD_EXODUS = xbmcaddon.Addon(id=EXODUS)
if os.path.exists(PATHVELOCITY): ADD_VELOCITY = xbmcaddon.Addon(id=VELOCITY)
if os.path.exists(PATHSALT): ADD_SALT = xbmcaddon.Addon(id=SALT)
if os.path.exists(PATHROYALWE): ADD_ROYALWE = xbmcaddon.Addon(id=ROYALWE)
if os.path.exists(PATHURLRES): ADD_URLRESOLVER = xbmcaddon.Addon(id=URLRESOLVER)

#################################
####CHECK UPDATE#################
#################################
	
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def updateSettings(name, update):
	if name == 'clear':
		ADDON.setSetting(id='buildname', value='')
		ADDON.setSetting(id='buildversion', value='')
		ADDON.setSetting(id='latestversion', value='')
		ADDON.setSetting(id='lastbuildcheck', value='')
		ADDON.setSetting(id='largeadult', value='NO')
		ADDON.setSetting(id='adult', value='NO')
	else:
		update = ADDON.setSetting(id=name, value=update)
	
def checkUpdate():
	link = OPEN_URL(BASEURLLOG+'version.txt').replace('\n','').replace('\r','')
	match = re.compile('name="(.+?)".+?ersion="(.+?)".+?ype="(.+?)".+?ate="(.+?)".+?ip="(.+?)".+?ui="(.+?)".+?escription="(.+?)".+?hange="(.+?)"').findall(link)
	BUILDNAME = ADDON.getSetting('buildname')
	BUILDVERSION = ADDON.getSetting('buildversion')
	for name,version,type,date,zip,gui,description,change in match:
		if name == BUILDNAME and version > BUILDVERSION:
			ADDON.setSetting('latestversion', version)
			yes_pressed = DIALOG.yesno(ADDONTITLE,"New version of your current build avaliable:", name+" v"+version, "Click Go to Build Page to install update.", yeslabel="Go to Build Page", nolabel="Ignore for 3 days")
			if yes_pressed:
				url = 'plugin://'+ADDON_ID+'/?mode=14&name='+urllib.quote_plus(name)+'&url='+zip
				xbmc.executebuiltin('ActivateWindow(10025 ,'+url+', return)')
			else: DIALOG.ok(ADDONTITLE, 'You can still update '+name+' to '+version+' from the Aftermath Wizard.')
	ADDON.setSetting('lastbuildcheck', str(TODAY))
	
def repoInstall():
	repozip = 'http://r.srfx.in/repo.zip'
	path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
	if not os.path.exists(path): os.makedirs(path)
	lib=os.path.join(path, 'aftermath.zip')
	try: os.remove(lib)
	except: pass
	downloader.download(repozip,lib)
	addonfolder = xbmc.translatePath(os.path.join('special://home','addons'))
	extract.all(lib,addonfolder)
	xbmc.sleep(1000)
	xbmc.executebuiltin('UpdateAddonRepos()')
	xbmc.executebuiltin('UpdateLocalAddons()')
	xbmc.sleep(1000)
	
def updateTrakt(type):
	traktfile = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ADDON_ID,'traktit'))
	if not os.path.exists(traktfile): f = open(traktfile, 'w+'); f.close()
	if type == 'clear':
		if os.path.exists(traktfile): os.remove(traktfile)
		f = open(traktfile, 'w+'); f.close()
		updateTrakt('settings')
	elif type == 'settings':
		if os.path.exists(PATHEXODUS): TRAKTEXODUS = ADD_EXODUS.getSetting('trakt.user'); REALEXODUS = ADD_EXODUS.getSetting('realdebrid.id')
		if os.path.exists(PATHVELOCITY): TRAKTVELOCITY = ADD_VELOCITY.getSetting('trakt_username')
		if os.path.exists(PATHSALT): TRAKTSALT = ADD_SALT.getSetting('trakt_user')
		if os.path.exists(PATHROYALWE): TRAKTROYAL = ADD_ROYALWE.getSetting('trakt_account')
		if os.path.exists(PATHURLRES): REALURL = ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id')
		updateSettings('exodus' ,TRAKTEXODUS)
		updateSettings('exodusreal' ,REALEXODUS)
		updateSettings('velocity' ,TRAKTVELOCITY)
		updateSettings('salt' ,TRAKTSALT)
		updateSettings('royalwe' ,TRAKTROYAL)
		updateSettings('urlresolver' ,REALURL)
	elif type == 'reinstall':
		with open(traktfile, 'r') as f:
			for line in f:
				add, set, val = line.replace('\n','').split("=")
				a=xbmcaddon.Addon(id=add)
				a.setSetting(set,val)
		DIALOG.ok(ADDONTITLE, 'Trakt settings restored.')
		updateTrakt('settings')
		f.closed
	elif type == 'update':
		if os.path.exists(traktfile): updateTrakt('clear')
		with open(traktfile, 'w') as f:
			for name in EXODUS_TRAKT: e = EXODUS+'='+name+'='+ADD_EXODUS.getSetting(name)+'\n'; f.write(e); print e
			for name in VELO_TRAKT:	e = VELOCITY+'='+name+'='+ADD_VELOCITY.getSetting(name)+'\n'; f.write(e); print e
			for name in SALT_TRAKT:	e = SALT+'='+name+'='+ADD_SALT.getSetting(name)+'\n'; f.write(e); print e
			for name in ROYAL_TRAKT: e = ROYALWE+'='+name+'='+ADD_ROYALWE.getSetting(name)+'\n'; f.write(e); print e
			for name in URL_REALDEBRID: e = URLRESOLVER+'='+name+'='+ADD_URLRESOLVER.getSetting(name)+'\n'; f.write(e); print e
		updateTrakt('settings')
		f.closed
		
def checkBuild():
	for skin in SKINCHECK:
		skinpath = xbmc.translatePath(os.path.join('special://home/addons',skin))
		if os.path.exists(skinpath): 
			current = skin
	if current == SKINCHECK[0]:
		gui = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.skinshortcuts','system.DATA.xml'))
		f = open(gui,mode='r'); g = f.read(); f.close()
		match = re.compile('<label>Aftermath (.+?)<\/label>').findall(g)
		build, ver = match[0].split(' ')
		ADDON.setSetting('buildname', 'Aftermath '+build)
		ADDON.setSetting('buildversion', ver[1:])
		ADDON.setSetting('lastbuildcheck', str(TODAY))
		checkUpdate()
	elif current == SKINCHECK[1]:
		gui = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/script.skinshortcuts','x5.DATA.xml'))
		f = open(gui,mode='r'); g = f.read(); f.close()
		match = re.compile('<label>Aftermath (.+?)<\/label>').findall(g)
		build, ver = match[0].split(' ')
		ADDON.setSetting('buildname', 'Aftermath '+build)
		ADDON.setSetting('buildversion', ver[1:])
		ADDON.setSetting('lastbuildcheck', str(TODAY))
		checkUpdate()
	elif current == SKINCHECK[2]:
		if KODIV >= '16': gui = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ADDON_ID,'guisettings.xml'))
		else: gui = xbmc.translatePath(os.path.join('special://home/userdata/',guisettings.xml'))
		f = open(gui,mode='r'); g = f.read(); f.close()
		match = re.compile('<setting type=\"string\" name=\"skin.aftermath.simple.SubSettings.3.Label\">(.+?)<\/setting>').findall(g)
		name, build, ver = match[0].replace('[COLOR dodgerblue]','').replace('[/COLOR]','').split(' ')
		ADDON.setSetting('buildname', 'Aftermath '+build)
		ADDON.setSetting('buildversion', ver[1:])
		ADDON.setSetting('lastbuildcheck', str(TODAY))
		checkUpdate()
	elif current == SKINCHECK[3]:
		yes_pressed = DIALOG.yesno(ADDONTITLE,"[COLOR dodgerblue]Aftermath[/COLOR] CCM is currently outdated and is no longer being updated.", "Please download one of the newer community builds.", yeslabel="Build Menu", nolabel="Ignore")
		if yes_pressed:
			url = 'plugin://'+ADDON_ID+'/?mode=2&name=BuildMenu&url=none'
			xbmc.executebuiltin('ActivateWindow(10025 ,'+url+', return)')
		else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	else:
		yes_pressed = DIALOG.yesno(ADDONTITLE,"Currently no build installed from [COLOR dodgerblue]Aftermath[/COLOR].", "Select 'Build Menu' to install a Community Build", yeslabel="Build Menu", nolabel="Ignore")
		if yes_pressed:
			url = 'plugin://'+ADDON_ID+'/?mode=2&name=BuildMenu&url=none'
			xbmc.executebuiltin('ActivateWindow(10025 ,'+url+', return)')
		else: DIALOG.ok(ADDONTITLE, 'You can still install a community build from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	
def writeAdvanced():
	if RAM > 1536: buffer = '209715200'
	else: buffer = '104857600'
	with open(ADVANCED, 'w+') as f:
		f.write('<advancedsettings>\n')
		f.write('	<network>\n')
		f.write('		<buffermode>2</buffermode>\n')
		f.write('		<cachemembuffersize>'+buffer+'</cachemembuffersize>\n')
		f.write('		<readbufferfactor>5</readbufferfactor>\n')
		f.write('		<curlclienttimeout>10</curlclienttimeout>\n')
		f.write('		<curllowspeedtime>10</curllowspeedtime>\n')
		f.write('	</network>\n')
		f.write('</advancedsettings>\n')
	f.close()
	
if not os.path.exists(REPO): repoInstall()

if BUILDCHECK <= str(NEXTCHECK): 
	updateTrakt('update')
	if BUILDNAME != "": checkUpdate()
	else: checkBuild()
	ADDON.setSetting('lastbuildcheck', str(TODAY))
	
if not os.path.exists(ADVANCED): writeAdvanced()