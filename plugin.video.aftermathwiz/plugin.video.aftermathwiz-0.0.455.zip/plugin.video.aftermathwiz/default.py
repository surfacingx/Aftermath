import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import datetime
import plugintools
from datetime import date
from addon.common.addon import Addon
from addon.common.net import Net

USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
ADDON_ID       = 'plugin.video.aftermathwiz'
ADDON          = xbmcaddon.Addon(id=ADDON_ID)
ADDONTITLE     = 'Aftermath Wizard'
VERSION        = '0.0.455'
DIALOG         = xbmcgui.Dialog()
DP             = xbmcgui.DialogProgress()
FANART         = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'fanart.jpg'))
ICON           = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ART            = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources/art/')) 
REPO           = xbmc.translatePath(os.path.join('special://home/addons','repository.aftermath'))
ADVANCED       = xbmc.translatePath(os.path.join('special://home/userdata','advancedsettings.xml'))
USERDATA       = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/',ADDON_ID))
DBPATH         = xbmc.translatePath('special://database')
TNPATH         = xbmc.translatePath('special://thumbnails');
BASEURL        = "http://cb.srfx.in/builds/"
BASEURLLOG     = BASEURL+'info/'
BUILDNAME      = ADDON.getSetting('buildname')
BUILDVERSION   = ADDON.getSetting('buildversion')
BUILDLATEST    = ADDON.getSetting('latestversion')
BUILDCHECK     = ADDON.getSetting('lastbuildcheck')
TODAY          = datetime.date.today()
NEXTCHECK      = TODAY - datetime.timedelta(days=3)
KEEPFAVS       = ADDON.getSetting('keepfavourites')
KEEPSOURCES    = ADDON.getSetting('keepsources')
SHOWADULT      = ADDON.getSetting('showadult')
LARGEADULTPACK = ADDON.getSetting('largeadult')
ADULTPACK      = ADDON.getSetting('adult')
EXCLUDES       = ['script.module.addon.common','repository.aftermath','plugin.video.aftermath','plugin.video.aftermathwiz']
BUILDS         = ['Aftermath Silvo','Aftermath Zephyr','Aftermath Simple','Aftermath Simple Lite']
PACK_ADULT     = ['plugin.video.empflix', 'plugin.video.erotik', 'plugin.video.uwc', 'plugin.video.videodevil', 'plugin.video.you.jizz', 'repository.whitecream', 'repository.xbmcadult']
PACK_LARGE     = ['plugin.video.empflix', 'plugin.video.erotik', 'plugin.video.fantasticc', 'plugin.video.hotgoo', 'plugin.video.largecamtube', 'plugin.video.lubetube', 'plugin.video.tube8', 'plugin.video.uwc', 'plugin.video.videodevil', 'plugin.video.wildfire', 'plugin.video.woodrocket', 'plugin.video.you.jizz', 'repository.ptom', 'repository.whitecream', 'repository.xbmcadult', 'repository.xxxadultxbmc']
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
RAM            = int(xbmc.getInfoLabel("System.Memory(total)")[:-2])
EXODUS         = 'plugin.video.exodus'
VELOCITY       = 'plugin.video.velocity'
SALT           = 'plugin.video.salts'
ROYALWE        = 'plugin.video.theroyalwe'
URLRESOLVER    = 'script.module.urlresolver'
EXODUS_TRAKT   = ['realdebrid.auth', 'realdebrid.id', 'realdebrid.refresh', 'realdebrid.secret', 'realdebrid.token', 'trakt.user', 'trakt.refresh', 'trakt.token']
VELO_TRAKT     = ['trakt_authorized', 'trakt_username', 'trakt_oauth_token', 'trakt_refresh_token']
SALT_TRAKT     = ['trakt_oauth_token', 'trakt_refresh_token', 'trakt_user']
ROYAL_TRAKT    = ['trakt_authorized', 'trakt_account', 'trakt_client_id', 'trakt_oauth_token', 'trakt_refresh_token', 'trakt_secret']
URL_REALDEBRID = ['RealDebridResolver_authorize', 'RealDebridResolver_autopick', 'RealDebridResolver_client_id', 'RealDebridResolver_client_secret', 'RealDebridResolver_enabled', 'RealDebridResolver_priority', 'RealDebridResolver_refresh','RealDebridResolver_token']
PATHEXODUS     = xbmc.translatePath(os.path.join('special://home/addons/',EXODUS))
PATHVELOCITY   = xbmc.translatePath(os.path.join('special://home/addons/',VELOCITY))
PATHSALT       = xbmc.translatePath(os.path.join('special://home/addons/',SALT))
PATHROYALWE    = xbmc.translatePath(os.path.join('special://home/addons/',ROYALWE))
PATHURLRES     = xbmc.translatePath(os.path.join('special://home/addons/',URLRESOLVER))
if os.path.exists(PATHEXODUS): ADD_EXODUS = xbmcaddon.Addon(id=EXODUS); TRAKTEXODUS = ADD_EXODUS.getSetting('trakt.user'); REALEXODUS = ADD_EXODUS.getSetting('realdebrid.id')
if os.path.exists(PATHVELOCITY): ADD_VELOCITY = xbmcaddon.Addon(id=VELOCITY); TRAKTVELOCITY = ADD_VELOCITY.getSetting('trakt_username')
if os.path.exists(PATHSALT): ADD_SALT = xbmcaddon.Addon(id=SALT); TRAKTSALT = ADD_SALT.getSetting('trakt_user')
if os.path.exists(PATHROYALWE): ADD_ROYALWE = xbmcaddon.Addon(id=ROYALWE); TRAKTROYAL = ADD_ROYALWE.getSetting('trakt_account')
if os.path.exists(PATHURLRES): ADD_URLRESOLVER = xbmcaddon.Addon(id=URLRESOLVER); REALURL = ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id')

#################################
####### MENUS ###################
#################################

def index():
	if BUILDNAME=='':
		addDir('Aftermath: No Build Installed','none',2,'',FANART)	
	else:
		vcheck = checkBuild('check',BUILDNAME,'version')
		if vcheck > BUILDVERSION: msg = BUILDNAME+'(v'+str(BUILDVERSION)+') - [COLOR red][B]NEW UPDATE: v'+vcheck+'[/B][/COLOR]'
		else: msg = BUILDNAME+'(v'+str(BUILDVERSION)+')'
		addDir(msg,BUILDNAME,14,' ',ART+BUILDNAME+'.png')	
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addDir('Aftermath Builds','BuildList',2,'',FANART)
	addDir('Aftermath Addon Packs','AddonsList',3,'',FANART)
	addDir('Aftermath Maintenance','Maintenance',4,'',FANART)
	addDir('Aftermath Guides','Guides',18,'',FANART)
	#addFile('Aftermath Version Check','VersionCheck',5,'',FANART)
	addFile('Aftermath Info','wizard',6,'',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addFile('Aftermath Settings','Settings',13,'',FANART)
	setView('movies', 'MAIN')


def fightNight():
	addFile('[I]I will do my best to update this list for fights.[/I]','','','',FANART)
	
def guideMenu():
	addFile('[I]Guides to help setup different accounts.[/I]','','','',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addDir('Aftermath Settings Up Trakt','trakt',19,'',FANART)
	addDir('Aftermath Settings Up Real Debrid','trakt',22,'',FANART)
	setView('movies', 'MAIN')
	
def traktMenu():
	addFile('[I]Register FREE Account at http://trakt.tv [/I]','','','',FANART)
	addFile('Aftermath Trakt Info','trakt','6','',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	if not os.path.exists(PATHEXODUS): addFile('Aftermath [COLOR red]Exodus: Not Installed[/COLOR]','','','',FANART)
	elif TRAKTEXODUS == "": addFile('Aftermath [COLOR red]Exodus: Not Registered[/COLOR]','exodus',20,'',FANART)
	else: addFile('Aftermath [COLOR green]Exodus: '+TRAKTEXODUS+'[/COLOR]','exodus',20,'',FANART)
	if not os.path.exists(PATHVELOCITY): addFile('Aftermath [COLOR red]Velocity: Not Installed[/COLOR]','','','',FANART)
	elif TRAKTVELOCITY == "": addFile('Aftermath [COLOR red]Velocity: Not Registered[/COLOR]','velocity',20,'',FANART)
	else: addFile('Aftermath [COLOR green]Velocity: '+TRAKTVELOCITY+'[/COLOR]','velocity',20,'',FANART)
	if not os.path.exists(PATHSALT): addFile('Aftermath [COLOR red]Salt: Not Installed[/COLOR]','','','',FANART)
	elif TRAKTSALT == "": addFile('Aftermath [COLOR red]Salt: Not Registered[/COLOR]','salt',20,'',FANART)
	else: addFile('Aftermath [COLOR green]Salt: '+TRAKTSALT+'[/COLOR]','salt',20,'',FANART)
	if not os.path.exists(PATHROYALWE): addFile('Aftermath [COLOR red]Royal We: Not Installed[/COLOR]','','','',FANART)
	elif TRAKTROYAL == "": addFile('Aftermath [COLOR red]Royal We: Not Registered[/COLOR]','royalwe',20,'',FANART)
	else: addFile('Aftermath [COLOR green]Royal We: '+TRAKTROYAL+'[/COLOR]','royalwe',20,'',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addFile('Aftermath Save Trakt & Real Debrid Data','update',21,'',FANART)
	addFile('Aftermath Recover Trakt & Real Debrid Data','reinstall',21,'',FANART)
	setView('movies', 'MAIN')
	
def debridMenu():
	addFile('[I]Register A Premium Account at http://real-debrid.com (Paid $20/180days)[/I]','','','',FANART)
	addFile('Aftermath Real Debrid Info','realdebrid','6','',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	if not os.path.exists(PATHEXODUS): addFile('Aftermath [COLOR red]Exodus: Not Installed[/COLOR]','','','',FANART)
	elif REALEXODUS == "": addFile('Aftermath [COLOR red]Exodus: Not Registered[/COLOR]','exodus',23,'',FANART)
	else: addFile('Aftermath [COLOR green]Exodus: '+REALEXODUS+'[/COLOR]','exodus',23,'',FANART)
	if not os.path.exists(PATHURLRES): addFile('Aftermath [COLOR red]URL Resolver: Not Installed[/COLOR]','','','',FANART)
	elif REALURL == "": addFile('Aftermath [COLOR red]URL Resolver: Not Registered[/COLOR]','url',23,'',FANART)
	else: addFile('Aftermath [COLOR green]URL Resolver: '+REALURL+'[/COLOR]','url',23,'',FANART)
	addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
	addFile('Aftermath Save Trakt & Real Debrid Data','update',21,'',FANART)
	addFile('Aftermath Recover Trakt & Real Debrid Data','reinstall',21,'',FANART)
	setView('movies', 'MAIN')
	
def buildMenu():
	if KODIV < 16:
		addFile('Aftermath Kodi v'+KODIV+' Build Info','builds',6,'',FANART)
		addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
		addDir('Aftermath Zephyr (v'+checkBuild('check','Aftermath Zephyr','version')+')','Aftermath Zephyr',14,'AZ.zip',ART+'AZ.png')
		addDir('Aftermath Silvo (v'+checkBuild('check','Aftermath Silvo','version')+')','Aftermath Silvo',14,'AN.zip',ART+'AN.png')
		addDir('Aftermath Simple (v'+checkBuild('check','Aftermath Simple','version')+')','Aftermath Simple',14,'AS.zip',ART+'AS.png')
		addDir('Aftermath Simple Lite (v'+checkBuild('check','Aftermath Simple','version')+')','Aftermath Simple Lite',14,'ASL.zip',ART+'ASL.png')
	else: 
		addFile('Aftermath Kodi v'+KODIV+' Build Info','builds',6,'',FANART)
		addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
		addDir('Aftermath Zephyr (v'+checkBuild('check','Aftermath Zephyr','version')+')','Aftermath Zephyr',14,'AZ.zip',ART+'AZ.png')
		addDir('Aftermath Silvo (v'+checkBuild('check','Aftermath Silvo','version')+')','Aftermath Silvo',14,'AN.zip',ART+'AN.png')
		addDir('Aftermath Simple (v'+checkBuild('check','Aftermath Simple','version')+')','Aftermath Simple',14,'AS.zip',ART+'AS.png')
		addDir('Aftermath Simple Lite (v'+checkBuild('check','Aftermath Simple','version')+')','Aftermath Simple Lite',14,'ASL.zip',ART+'ASL.png')
	setView('movies', 'MAIN')

def addonPacks():
    addFile('Aftermath Packs Info','addons',6,'',FANART)
    addFile('[COLOR dodgerblue]==================================================[/COLOR]','','','',FANART)
    addDir('Aftermath Large Adult Pack','Aftermath Large Adult Pack',15,'AP1.zip',FANART)
    addDir('Aftermath Adult Pack','Aftermath Adult Pack',15,'AP2.zip',FANART)
    setView('movies', 'MAIN')
	
def maintenance():
    addFile('Aftermath Clear Cache','Clean Cache',7,'',FANART)
    addDir('Aftermath Fresh Start','Fresh Start',8,'',FANART)
    addFile('Aftermath Clear Packages','Clear Packages',9,'',FANART)
    addFile('Aftermath Force Updates','Force Updates',17,'',FANART)
    setView('movies', 'MAIN')
	
def viewBuild(name,url):
    if KODIV < 16:
        vcheck = checkBuild('check',name,'version')
        if name == BUILDNAME and vcheck > BUILDVERSION: msg = msg = name+'(v'+vcheck+') - [COLOR red][B]NEW UPDATE(Current: v'+str(BUILDVERSION)+')[/B][/COLOR]'
        else: msg = name+'(v'+str(BUILDVERSION)+')'
        addFile( msg,name,'', url, FANART)
        addFile('[COLOR dodgerblue]==============[ Install Options ]=======================[/COLOR]','','','',FANART)
        addFile('Aftermath Clean Install - [I][B](Recommended)[/B][/I]',name,10,'fresh',FANART)
        addFile('Aftermath Normal Install',name,10,'normal',FANART)
        addFile('Aftermath Apply guisettings.xml fix',name,10,'gui',FANART)
        addFile('[COLOR dodgerblue]==============[ Information ]=========================[/COLOR]','','','',FANART)
        addFile('Aftermath Build Description','description',12,name,FANART)
        addFile('Aftermath Change Log','change',12,name,FANART)
        setView('movies', 'MAIN')
    else: 
        vcheck = checkBuild('check',name,'version')
        if name == BUILDNAME and vcheck > BUILDVERSION: msg = msg = name+'(v'+vcheck+') - [COLOR red][B]NEW UPDATE(Current: v'+str(BUILDVERSION)+')[/B][/COLOR]'
        else: msg = name+'(v'+str(BUILDVERSION)+')'
        addFile( msg,name,'', url, FANART)
        addFile('[COLOR dodgerblue]==============[ Install Options ]=======================[/COLOR]','','','',FANART)
        addFile('Aftermath Clean Install - [I][B](Recommended)[/B][/I]',name,10,'fresh',FANART)
        addFile('Aftermath Normal Install',name,10,'normal',FANART)
        addFile('Aftermath Apply guisettings.xml fix',name,10,'gui',FANART)
        addFile('[COLOR dodgerblue]==============[ Information ]=========================[/COLOR]','','','',FANART)
        addFile('Aftermath Build Description','description',12,name,FANART)
        addFile('Aftermath Change Log','change',12,name,FANART)
        setView('movies', 'MAIN')
	
def viewAddon(name,url):
    addFile(name,name,'', url, FANART)
    addFile('[COLOR dodgerblue]==============[ Install Options ]=======================[/COLOR]','','','',FANART)
    addFile('Aftermath Install Pack',name,11,'install',FANART)
    addFile('Aftermath Remove Pack',name,11,'remove',FANART)
    addFile('Aftermath Add to Favourites',name,11,'favs',FANART)
    addFile('[COLOR dodgerblue]==============[ Information ]=========================[/COLOR]','','','',FANART)
    addFile('Aftermath Addon Pack Description','description',12,name,FANART)
    addFile('Aftermath Change Log','change',12,name,FANART)
    setView('movies', 'MAIN')
	

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def info(display):
    if display=='builds':
        msg = 'Here are a list of builds offered in the wizard and a small description, for more information on the build then click on the description or change log in the build menu.\n\n[COLOR dodgerblue]Aftermath Zephyr(v'+checkBuild('check','Aftermath Zephyr','version')+')[/COLOR]: Community build using the skin Arctic: Zephyr.  Filled with tons of addons, primarily made for Fire TV Boxes.\n\n[COLOR dodgerblue]Aftermath Silvo(v'+checkBuild('check','Aftermath Silvo','version')+')[/COLOR]: Community build using the Aoen Nox: Silvo.  Filled with tons of addons and widgets, primarily made for Fire TV Boxes.\n\n[COLOR dodgerblue]Aftermath Simple(v'+checkBuild('check','Aftermath Simple','version')+')[/COLOR]: Light weight build using CCM Helix skin.  Only the top addons are included without alot of the extra stuff, primarily for Fire TV Sticks.\n\n[COLOR dodgerblue]Aftermath Simple Lite(v'+checkBuild('check','Aftermath Simple Lite','version')+')[/COLOR]: Same as the Aftermath Simple build except addons are only downloaded when first try to load them to help save space.\n\n[COLOR dodgerblue]Aftermath CCM[/COLOR]: This custom build has been discontinued and replaced with Aftermath Zephyr or Aftermath Silvo.'
    elif display=='addons':
        msg = 'Addon packs are a collection of alike addons that are not included in any of the custom builds but can be easily added at the click of a button.\n\n[COLOR dodgerblue]Large Adults Pack[/COLOR]: Empflix, Erotik, Fantasticc, Hotgoo, Largecamtube, Lubetube, Tube8, Ultimate Whitecream, Videodevil, Wildfire, Woodrocket, YouJizz, & there repositories.\n\n[COLOR dodgerblue]Adults Pack[/COLOR]: EmpFlix, Erotik, Ultimate Whitecream, Videodevil, YouJizz, & there repositories.'
    elif display=='wizard':
		url = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID , 'changelog.txt'))
		f = open(url,mode='r'); change = f.read(); f.close()
		msg = 'Welcome to the home of the Aftermath Custom Builds.  You can install the latest version of our builds with ease and get notifications when updates have been released.  Also you can download addon packs that contain various addons.\n\nCheck http://srfx.in for latest guides and tutorials.\n\nAftermath Wizard Change Log:\n\n'+change
    elif display=='trakt':
		url = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources', 'trakt.txt'))
		f = open(url,mode='r'); msg = f.read(); f.close()
    elif display=='realdebrid':
		url = xbmc.translatePath(os.path.join('special://home/addons/' + ADDON_ID + '/resources', 'debrid.txt'))
		f = open(url,mode='r'); msg = f.read(); f.close()
    TextBoxes(ADDONTITLE, msg)
    
#################################
####CHECK UPDATE#################
#################################
	
def checkBuild(param,bname,ret):
    link = OPEN_URL(BASEURLLOG+'version.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?ersion="(.+?)".+?ype="(.+?)".+?ate="(.+?)".+?ip="(.+?)".+?ui="(.+?)".+?escription="(.+?)".+?hange="(.+?)"').findall(link)
    if param == 'check':
	    for name,version,type,date,zip,gui,description,change in match:
		    if name == bname:
		        if ret=='version': 
			    	return version	
		        elif ret=='date': 
			    	return date	
		        elif ret=='zip': 
			    	return zip	
		        elif ret=='gui': 
			    	return gui	
		        elif ret=='description': 
			    	return description
		        elif ret=='change': 
			    	return change
    else:
        vinfo = 'Here is a list of the latest version of the builds and addon packs, current build installed will be highlighted:\n\n'
        vbuild = '[COLOR dodgerblue]==============Custom Builds=========================[/COLOR]\n'
        vaddon = '[COLOR dodgerblue]==============Addon Packs=========================[/COLOR]\n'
        for name,version,type,date,zip,gui,description,change in match:
            if type == 'build':
                if name == BUILDNAME:
                    if BUILDVERSION < version:
                        vbuild += "[COLOR dodgerblue]Name: "+name+" - [B]NEW[/B]\n"
                        vbuild += "Version: "+version+"\n"
                        vbuild += "Date: "+date+"\n"
                        vbuild += "Change Log: "+change+"[/COLOR]\n\n"
                    else:
                        vbuild += "[COLOR dodgerblue]Name: "+name+" - [B]Current Version[/B]\n"
                        vbuild += "Version: "+version+"\n"
                        vbuild += "Date: "+date+"\n"
                        vbuild += "Change Log: "+change+"[/COLOR]\n\n"
                else:
                    vbuild += "Name: "+name+"\n"
                    vbuild += "Version: "+version+"\n"
                    vbuild += "Date: "+date+"\n"
                    vbuild += "Change Log: "+change+"\n\n"
            elif type == 'addon':
                vaddon += "Name: "+name+"\n"
                vaddon += "Version: "+version+"\n"
                vaddon += "Date: "+date+"\n"
                vaddon += "Change Log: "+change+"\n\n"
        TextBoxes(ADDONTITLE, vinfo+vbuild+vaddon)

def updateSettings(name, update):
	if name == 'clear':
		ADDON.setSetting(id='buildname', value='')
		ADDON.setSetting(id='buildversion', value='')
		ADDON.setSetting(id='latestversion', value='')
		ADDON.setSetting(id='lastbuildcheck', value='')
		ADDON.setSetting(id='largeadult', value='')
		ADDON.setSetting(id='adult', value='')
	else:
		update = ADDON.setSetting(id=name, value=update)
	
#################################
####VIEW LOG#####################
#################################
	
def viewLog(name,type):
	changeURL = checkBuild('check',name,type)
	link = OPEN_URL(BASEURLLOG+changeURL)
	title = ADDONTITLE+' - '+name+': '+checkBuild('check',name,'version')
	TextBoxes(title, link)

def addonList():
	path = xbmc.translatePath(os.path.join('special://home','addons'))
	dirs = os.listdir( path )
	vid = ''; prog = ''; repo = ''; audio = '';
	for file in dirs:
		addon = xbmc.translatePath(os.path.join('special://home/addons/'+file,'addon.xml'))
		if os.path.exists(addon): 
			xml = open(addon,mode='r')
			g = xml.read().replace('\n','').replace('\r','')
			xml.close()
			match = re.compile('<addon *.+?ame="(.+?)".+?>').findall(g)
			title = match[0]
			type = re.compile('<provides>(.+?)</provides>').findall(g)
			if len(type) > 0: type2 = type[0].split(' '); 
			else: type2 = ''
			if 'executable' in type2: 
				if prog != '': prog += ', '+title
				else: prog = title
			elif 'audio' in type2: 
				if audio != '': audio += ', '+title
				else: audio = title
			elif 'video' in type2: 
				if vid != '': vid += ', '+title
				else: vid = title
			elif file[:11] == 'repository.': 
				if repo != '': repo += ', '+title
				else: repo = title
	if BUILDNAME != "":
		with open(xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ADDON_ID,BUILDNAME+'.txt')), 'w') as f:
			f.write("Video Addons: "+vid+"\n\nProgram: "+prog+"\n\nAudio: "+audio+"\n\nRepo: "+repo)
		f.close()
	
#################################
####BUILD/ADDON INSTALL##########
#################################

def buildWizard(name, type):
	if type == 'gui':
		if name != BUILDNAME:
			DIALOG.ok(ADDONTITLE, name+" community build is not currently installed.", "Please install the build before doing a guiFix.")
		else:
			yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to apply the guifix for:', name+'?', nolabel='No, Cancel',yeslabel='Yes, Remove')
			if yes_pressed:
				buildzip = BASEURL+checkBuild('check',name,'gui')
				path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
				if not os.path.exists(path): os.makedirs(path)
				DP.create(ADDONTITLE,"Downloading "+ name+" GuiFix",'', 'Please Wait')
				lib=os.path.join(path, name+'.zip')
				try: os.remove(lib)
				except: pass
				downloader.download(buildzip, lib, DP)
				addonfolder = xbmc.translatePath(os.path.join('special://home','userdata'))
				time.sleep(2)
				DP.update(0,"", "Installing "+name)
				extract.all(lib,addonfolder,DP)
				killxbmc()
	elif type == 'fresh':
		freshStart(params)
	elif type == 'normal':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to install:', name+'?', nolabel='No, Cancel',yeslabel='Yes, Remove')
		if yes_pressed:
			buildzip = BASEURL+checkBuild('check',name,'zip')
			path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
			if not os.path.exists(path): os.makedirs(path)
			DP.create(ADDONTITLE,"Downloading "+ name,'', 'Please Wait')
			lib=os.path.join(path, name+'.zip')
			try: os.remove(lib)
			except: pass
			downloader.download(buildzip, lib, DP)
			addonfolder = xbmc.translatePath(os.path.join('special://','home'))
			time.sleep(2)
			DP.update(0,"", "Installing "+name)
			extract.all(lib,addonfolder,DP)
			updateSettings('buildname', name)
			updateSettings('buildversion', checkBuild('check', name,'version'))
			updateSettings('latestversion', checkBuild('check', name,'version'))
			updateSettings('lastbuildcheck', str(TODAY))
			DIALOG.ok(ADDONTITLE, "To save changes you now need to force close Kodi, Press OK to force close Kodi")
			killxbmc()
	
def addonWizard(name,url):
	setupdate = name.replace(' ','').replace('Aftermath','').replace('Pack','').lower()
	if url == 'remove':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to remove:', name+'?', nolabel='No, Cancel',yeslabel='Yes, Remove')
		if yes_pressed:
			addon = xbmc.translatePath(os.path.join('special://home','addons'))
			user = xbmc.translatePath(os.path.join('special://home/userdata','addon_data'))
			if setupdate == 'adult':
				for d in PACK_ADULT: 
					if os.path.exists(os.path.join(addon,d)): shutil.rmtree(os.path.join(addon,d),ignore_errors=True, onerror=None)
					if os.path.exists(os.path.join(user,d)): shutil.rmtree(os.path.join(user,d),ignore_errors=True, onerror=None)
				updateSettings(setupdate, '')
				DIALOG.ok(ADDONTITLE, name+" has successfully been uninstalled.","The addons will still show up until Kodi is restarted.","Force Close Kodi")
			elif setupdate == 'largeadult':
				for d in PACK_LARGE: 
					if os.path.exists(os.path.join(addon,d)): shutil.rmtree(os.path.join(addon,d),ignore_errors=True, onerror=None)
					if os.path.exists(os.path.join(user,d)): shutil.rmtree(os.path.join(user,d),ignore_errors=True, onerror=None)
				updateSettings(setupdate, '')
				DIALOG.ok(ADDONTITLE, name+" has successfully been uninstalled.","The addons will still show up until Kodi is restarted.","Force Close Kodi Now!")
			killxbmc()
		else: DIALOG.ok(ADDONTITLE, name+" was not Removed!")
	elif url == 'install':
		yes_pressed = DIALOG.yesno(ADDONTITLE, 'Would you like to install:', name+'?', nolabel='No, Cancel',yeslabel='Yes, Install')
		if yes_pressed:
			addonzip = BASEURL+checkBuild('check',name,'zip')
			path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
			if not os.path.exists(path): os.makedirs(path)
			DP.create(ADDONTITLE,"Downloading "+ name,'', 'Please Wait')
			lib=os.path.join(path, name+'.zip')
			try: os.remove(lib)
			except:	pass
			downloader.download(addonzip, lib, DP)
			addonfolder = xbmc.translatePath(os.path.join('special://','home'))
			time.sleep(2)
			DP.update(0,"", "Installing your addon pack.")
			extract.all(lib,addonfolder,DP)
			xbmc.sleep(1000)
			xbmc.executebuiltin('UpdateAddonRepos()')
			xbmc.executebuiltin('UpdateLocalAddons()')
			xbmc.sleep(1000)
			updateSettings(setupdate, checkBuild('check', name, 'version'))
			DIALOG.ok(ADDONTITLE, name+" has successfully been installed.")
		else: DIALOG.ok(ADDONTITLE, name+" was not Installed!")
	if url == 'favs': DIALOG.ok(ADDONTITLE, "Currently in the works.")
	
################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def deletePackages(url):
	print '############################################################       DELETING PACKAGES             ###############################################################'
	packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
	if os.path.exists(packages_cache_path):
		try:    
			for root, dirs, files in os.walk(packages_cache_path):
				file_count = 0
				file_count += len(files)
				# Count files and give option to delete
				if file_count > 0:
					if DIALOG.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
						for f in files:	os.unlink(os.path.join(root, f))
						for d in dirs: shutil.rmtree(os.path.join(root, d))
						DIALOG.ok(ADDONTITLE, "Packages Successfuly Removed", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")
				else: DIALOG.ok(ADDONTITLE, "No Package Files Found.", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")
		except: DIALOG.ok(ADDONTITLE, "Sorry we were not able to remove Package Files", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")
	else: DIALOG.ok(ADDONTITLE, "No Package Files Found.", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")

#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
	
def deleteCacheFiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        	# Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files:
                        try: os.unlink(os.path.join(root, f))
                        except: pass
                    for d in dirs:
                        try: shutil.rmtree(os.path.join(root, d))
                        except: pass
            else: pass

    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                if DIALOG.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass
	# Set path to Cydia Archives cache files
    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
			# Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass                
    # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)        
			# Count files and give option to delete
            if file_count > 0:    
                if DIALOG.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass
                
    # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
			# Count files and give option to delete
            if file_count > 0:    
                if DIALOG.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass            
                
    # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
			# Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass
                
    # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)        
			# Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass

	# Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
			# Count files and give option to delete
            if file_count > 0:
                if DIALOG.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?", nolabel='No, Cancel',yeslabel='Yes, Remove'):
                    for f in files: os.unlink(os.path.join(root, f))
                    for d in dirs: shutil.rmtree(os.path.join(root, d))
            else: pass
    DIALOG.ok(ADDONTITLE, " All Cache Files Removed", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")
 
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
    choice = DIALOG.yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        DIALOG.ok("[COLOR=yellow][B]TO COMPLETE AFTERMATH INSTALL[/COLOR][/B]", "Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        DIALOG.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")    

##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def freshStart(params):
    fname = str(params['name']).replace('+',' ')
    fmode = str(params['mode'])
    plugintools.log("freshstart.main_list "+repr(params))
    if fmode == '10': yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings", "Before installing "+fname+"?", nolabel='No, Cancel',yeslabel='Yes, Continue')
    else: yes_pressed=DIALOG.yesno(ADDONTITLE,"Do you wish to restore your","Kodi configuration to default settings?", nolabel='No, Cancel',yeslabel='Yes, Continue')
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=ADDON_ID).getAddonInfo('path')
        addonPath=xbmc.translatePath(addonPath)
        xbmcPath=os.path.join(addonPath,"..","..")
        xbmcPath=os.path.abspath(xbmcPath)
        plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        DP.create(ADDONTITLE,"Clearing all files and folders:",'', '')
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
				dirs[:] = [d for d in dirs if d not in EXCLUDES]
				for name in files:
					file = 0
					file_count = len(files)
					if name == 'sources.xml' and KEEPSOURCES == 'true':
						plugintools.log("Keep Sources: "+root+" "+name)					
					elif name == 'favourites.xml' and KEEPFAVS == 'true':
						plugintools.log("Keep Favourites: "+root+" "+name)					
					else:
						DP.update(int(file / file_count * 100), '', 'File: [COLOR yellow]'+name+'[/COLOR]', '')
						try: os.remove(os.path.join(root,name))
						except:
							if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
							plugintools.log("Error removing "+root+" "+name)
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
				dirs[:] = [d for d in dirs if d not in EXCLUDES]							
				for name in dirs:
					fold = 0
					fold_count = len(dirs)
					DP.update(int(fold / fold_count * 100), '', 'Folder: [COLOR yellow]'+name+'[/COLOR]', '')
					if name not in ["Database","userdata","addons","addon_data"]:
						try: os.rmdir(os.path.join(root,name))
						except:
							#if name not in : failed=True
							shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)
							plugintools.log("Error removing "+root+" "+name)
            DP.close()
            updateSettings('clear', '')
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install")
            else: plugintools.log("freshstart.main_list User files partially removed")
            if fmode == '10': 
				DIALOG.ok(ADDONTITLE, "Your current setup for kodi has been cleared!", "Now we will install: "+fname)
				buildWizard(fname, 'normal')
            else: 
				DIALOG.ok(ADDONTITLE, "The process is complete, you're now back to a fresh Kodi configuration with Aftermath Wizard","Please reboot your system or restart Kodi in order for the changes to be applied.")
				killxbmc()
        except: 
            plugintools.message(ADDONTITLE,"Problem found","Your settings has not been changed")
            import traceback
            plugintools.log(traceback.format_exc())
            plugintools.log("freshstart.main_list NOT removed")
    else: plugintools.message(ADDONTITLE,"Your settings","has not been changed"); plugintools.add_item(action="",title="Done",folder=False)

	
#################################
##### TRAKT & REAL DEBRID #######
#################################

def updateTrakt(type):
	traktfile = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/'+ADDON_ID,'traktit'))
	if not os.path.exists(traktfile):
		if not os.path.exists(USERDATA): os.makedirs(USERDATA)
		f = open(traktfile, 'w+').close()
	if type == 'clear':
		if os.path.exists(traktfile): os.remove(traktfile)
		f = open(traktfile, 'w+'); f.close()
		updateTrakt('settings')
	elif type == 'settings':
		if os.path.exists(PATHEXODUS): TRAKTEXODUS = ADD_EXODUS.getSetting('trakt.user'); REALEXODUS = ADD_EXODUS.getSetting('realdebrid.id'); updateSettings('exodus' ,TRAKTEXODUS); updateSettings('exodusreal' ,REALEXODUS)
		if os.path.exists(PATHVELOCITY): TRAKTVELOCITY = ADD_VELOCITY.getSetting('trakt_username'); updateSettings('velocity' ,TRAKTVELOCITY)
		if os.path.exists(PATHSALT): TRAKTSALT = ADD_SALT.getSetting('trakt_user'); updateSettings('salt' ,TRAKTSALT)
		if os.path.exists(PATHROYALWE): TRAKTROYAL = ADD_ROYALWE.getSetting('trakt_account'); updateSettings('royalwe' ,TRAKTROYAL)
		if os.path.exists(PATHURLRES): REALURL = ADD_URLRESOLVER.getSetting('RealDebridResolver_client_id'); updateSettings('urlresolver' ,REALURL)
	elif type == 'reinstall':
		with open(traktfile, 'r') as f:
			for line in f:
				add, set, val = line.replace('\n','').split("=")
				a=xbmcaddon.Addon(id=add)
				a.setSetting(set,val)
		DIALOG.ok(ADDONTITLE, 'Trakt settings restored.')
		updateTrakt('settings')
		f.closed
	elif type == 'update':
		if os.path.exists(traktfile): updateTrakt('clear')
		with open(traktfile, 'w') as f:
			if os.path.exists(PATHEXODUS): 
				for name in EXODUS_TRAKT: e = EXODUS+'='+name+'='+ADD_EXODUS.getSetting(name)+'\n'; f.write(e); print e
			if os.path.exists(PATHVELOCITY): 
				for name in VELO_TRAKT:	e = VELOCITY+'='+name+'='+ADD_VELOCITY.getSetting(name)+'\n'; f.write(e); print e
			if os.path.exists(PATHSALT): 
				for name in SALT_TRAKT:	e = SALT+'='+name+'='+ADD_SALT.getSetting(name)+'\n'; f.write(e); print e
			if os.path.exists(PATHROYALWE): 
				for name in ROYAL_TRAKT: e = ROYALWE+'='+name+'='+ADD_ROYALWE.getSetting(name)+'\n'; f.write(e); print e
			if os.path.exists(PATHURLRES): 
				for name in URL_REALDEBRID: e = URLRESOLVER+'='+name+'='+ADD_URLRESOLVER.getSetting(name)+'\n'; f.write(e); print e
		DIALOG.ok(ADDONTITLE, 'Trakt settings updated.')
		updateTrakt('settings')
		f.closed

def activateTrakt(name):
	if name == 'exodus':
		if os.path.exists(PATHEXODUS): url = 'RunPlugin(plugin://plugin.video.exodus/?action=authTrakt)'
		else: DIALOG.ok(ADDONTITLE, 'Exodus is not currently installed.')
	elif name == 'velocity': 
		if os.path.exists(PATHVELOCITY): url = 'RunPlugin(plugin://plugin.video.velocity/?mode=get_pin)'
		else: DIALOG.ok(ADDONTITLE, 'Velocity is not currently installed.')
	elif name == 'salt': 
		if os.path.exists(PATHSALT): url = 'RunPlugin(plugin://plugin.video.salts/?mode=get_pin&amp;sf_options=fanart%3Dspecial%3A%2F%2Fhome%2Faddons%5Cplugin.video.salts%5Cfanart.jpg%26_options_sf)'
		else: DIALOG.ok(ADDONTITLE, 'SALTS is not currently installed.')
	elif name == 'royalwe': 
		if os.path.exists(PATHROYALWE): url = 'RunPlugin(plugin://plugin.video.theroyalwe/?mode=authorize_trakt)'
		else: DIALOG.ok(ADDONTITLE, 'The Royal We is not currently installed.')
	xbmc.executebuiltin(url)
	
def activateDebrid(name):
	if name == 'exodus': 
		if os.path.exists(PATHROYALWE): url = 'RunPlugin(plugin://plugin.video.exodus/?action=rdAuthorize)'
		else: DIALOG.ok(ADDONTITLE, 'Exodus is not currently installed.')
	elif name == 'url':
		if os.path.exists(PATHURLRES): 
			ADD_URLRESOLVER.setSetting('RealDebridResolver_authorize', 'true')
			DIALOG.ok(ADDONTITLE, "URL Resolver's RD has been set to Authorized!", "A RD link will be launched to Authorize URLRESOLVER for Real Debrid.","SALT, VELOCITY and a few other addons use URL Resolver.")
			url = 'PlayMedia(plugin://plugin.video.salts/?rand=1456637406.47&trakt_id=218281&class_url=http%3A%2F%2Fthevideo.me%2Fn9xc77nmyet3&episode=&mode=resolve_source&class_name=PrimeWire&season=&direct=False&video_type=Movie)'
		else: DIALOG.ok(ADDONTITLE, 'URLRESOLVER is not currently installed.')
	xbmc.executebuiltin(url)
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleaneDParams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleaneDParams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')

def addDir(display,name,mode,url,fanart):
        u=sys.argv[0]+"?mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&url="+urllib.quote_plus(url)
        ok=True
        display = display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=ICON)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
        liz.setProperty( "Fanart_Image", fanart )
     	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addFile(display,name,mode,url,fanart):
        u=sys.argv[0]+"?mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&url="+urllib.quote_plus(url)
        ok=True
        display = display.replace('Aftermath', '[COLOR dodgerblue]Aftermath[/COLOR]')
        liz=xbmcgui.ListItem(display, iconImage="DefaultFolder.png", thumbnailImage=ICON)
        liz.setInfo( type="Video", infoLabels={ "Title": display, "Plot": "Aftermath Builds" } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

		
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(ADDONTITLE)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
if mode==None:
        index()

elif mode==2:
        buildMenu()

elif mode==3:
        addonPacks()
		
elif mode==4:
        maintenance()
		
elif mode==5:
		checkBuild('display','all', '')

elif mode==6:
		info(name)		
	
elif mode==7:
        deleteCacheFiles(url)
		
elif mode==8:        
		freshStart(params)
	
elif mode==9:
		deletePackages(url)
		
elif mode==10:
        buildWizard(name,url)

elif mode==11:
        addonWizard(name,url)

elif mode==12:
		viewLog(url,name)
		
elif mode==13:
		ADDON.openSettings()
		
elif mode==14:
		viewBuild(name,url)
		
elif mode==15:
		viewAddon(name,url)
		
elif mode==16:
		killxbmc()

elif mode==17:
		xbmc.executebuiltin('UpdateAddonRepos()')
		xbmc.executebuiltin('UpdateLocalAddons()')
		DIALOG.ok(ADDONTITLE, "All Add-ons and Repos have been Forced To Update!", "[COLOR steelblue]Brought To You By Aftermath[/COLOR]")
		
elif mode==18:
	guideMenu()
	
elif mode==19:
	traktMenu()
	
elif mode==20:
	activateTrakt(name)
	
elif mode==21:
	updateTrakt(name)
	
elif mode==22:
	debridMenu()
	
elif mode==23:
	activateDebrid(name)
	
elif mode=='updatecheck':
	vcheck = checkBuild('check',BUILDNAME,'version')
	if vcheck > BUILDVERSION: 
		yes=DIALOG.yesno('There is an updated version of '+BUILDNAME+': v'+vcheck, 'Would you like to do a fresh install of it?', nolabel='No Thanks!',yeslabel='Yes Update!')
		if yes: buildWizard(BUILDNAME, 'fresh')
		else: DIALOG.ok(ADDONTITLE, 'You can still update '+BUILDNAME+' from '+BUILDVERSION+' to '+vcheck+' from the [COLOR dodgerblue]Aftermath[/COLOR] Wizard.')
	else: DIALOG.ok(ADDONTITLE, 'You are currently running the newest version of:', BUILDNAME+' (v'+BUILDVERSION+')')
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))